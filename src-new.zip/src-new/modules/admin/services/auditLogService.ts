import { PrismaClient } from '@prisma/client';
import { 
  AuditLog, 
  AuditLogFilters, 
  AuditLogListResponse, 
  PaginationInfo,
  AuditLogStats,
  UserActivitySummary,
  SystemActivitySummary,
  AuditLogDashboard
} from '../types';

const prisma = new PrismaClient();

export class AuditLogService {
  /**
   * Get all audit logs with filtering, sorting, and pagination
   */
  static async getAuditLogs(filters: AuditLogFilters): Promise<AuditLogListResponse> {
    try {
      const {
        search = '',
        action = '',
        userId = '',
        startDate,
        endDate,
        page = 1,
        limit = 10,
        sortBy = 'timestamp',
        sortOrder = 'desc'
      } = filters;

      const skip = (page - 1) * limit;

      // Build where clause
      const where: any = {};

      if (search) {
        where.OR = [
          { action: { contains: search, mode: 'insensitive' } },
          { description: { contains: search, mode: 'insensitive' } },
          { ipAddress: { contains: search, mode: 'insensitive' } },
          { userAgent: { contains: search, mode: 'insensitive' } }
        ];
      }

      if (action) {
        where.action = action;
      }

      if (userId) {
        where.userId = userId;
      }

      if (startDate) {
        where.timestamp = { ...where.timestamp, gte: new Date(startDate) };
      }

      if (endDate) {
        where.timestamp = { ...where.timestamp, lte: new Date(endDate) };
      }

      // Get total count
      const totalCount = await prisma.auditLog.count({ where });

      // Get audit logs with pagination
      const auditLogs = await prisma.auditLog.findMany({
        where,
        skip,
        take: limit,
        orderBy: { [sortBy]: sortOrder },
        include: {
          user: {
            select: {
              id: true,
              name: true,
              email: true,
              role: true
            }
          }
        }
      });

      // Transform audit logs
      const transformedLogs: AuditLog[] = auditLogs.map(log => ({
        id: log.id,
        action: log.action,
        description: log.description,
        userId: log.userId,
        userName: log.user?.name || 'Unknown',
        userEmail: log.user?.email || 'Unknown',
        userRole: log.user?.role || 'Unknown',
        resource: 'system',
        resourceId: log.id,
        ipAddress: log.ipAddress || undefined,
        userAgent: log.userAgent || undefined,
        metadata: log.metadata as Record<string, any> || undefined,
        timestamp: log.timestamp,
        createdAt: log.createdAt
      }));

      const totalPages = Math.ceil(totalCount / limit);

      const pagination: PaginationInfo = {
        page,
        limit,
        totalPages,
        totalItems: totalCount,
        hasNext: page < totalPages,
        hasPrev: page > 1
      };

      return {
        auditLogs: transformedLogs,
        pagination,
        filters,
        totalCount
      };
    } catch (error) {
      console.error('Error fetching audit logs:', error);
      throw new Error('Failed to fetch audit logs');
    }
  }

  /**
   * Get audit log by ID
   */
  static async getAuditLogById(id: string): Promise<AuditLog | null> {
    try {
      const log = await prisma.auditLog.findUnique({
        where: { id },
        include: {
          user: {
            select: {
              id: true,
              name: true,
              email: true,
              role: true
            }
          }
        }
      });

      if (!log) {
        return null;
      }

      return {
        id: log.id,
        action: log.action,
        description: log.description,
        userId: log.userId,
        userName: log.user?.name || 'Unknown',
        userEmail: log.user?.email || 'Unknown',
        userRole: log.user?.role || 'Unknown',
        resource: 'system',
        resourceId: log.id,
        ipAddress: log.ipAddress || undefined,
        userAgent: log.userAgent || undefined,
        metadata: log.metadata as Record<string, any> || undefined,
        timestamp: log.timestamp,
        createdAt: log.createdAt
      };
    } catch (error) {
      console.error('Error fetching audit log by ID:', error);
      throw new Error('Failed to fetch audit log');
    }
  }

  /**
   * Get audit log statistics
   */
  static async getAuditLogStats(filters: {
    startDate?: string;
    endDate?: string;
  }): Promise<AuditLogStats> {
    try {
      const where: any = {};

      if (filters.startDate) {
        where.timestamp = { ...where.timestamp, gte: new Date(filters.startDate) };
      }

      if (filters.endDate) {
        where.timestamp = { ...where.timestamp, lte: new Date(filters.endDate) };
      }

      const [total, byAction, byUser, byDay] = await Promise.all([
        prisma.auditLog.count({ where }),
        prisma.auditLog.groupBy({
          by: ['action'],
          where,
          _count: { action: true }
        }),
        prisma.auditLog.groupBy({
          by: ['userId'],
          where,
          _count: { userId: true }
        }),
        prisma.auditLog.groupBy({
          by: ['timestamp'],
          where,
          _count: { id: true }
        })
      ]);

      // Process by action
      const actionStats: { [key: string]: number } = {};
      byAction.forEach(item => {
        actionStats[item.action] = item._count.action;
      });

      // Process by user
      const userStats: { [key: string]: number } = {};
      for (const item of byUser) {
        const user = await prisma.user.findUnique({
          where: { id: item.userId },
          select: { name: true }
        });
        const userName = user?.name || 'Unknown';
        userStats[userName] = item._count.userId;
      }

      // Process by day
      const dailyStats = byDay.map(item => ({
        date: item.timestamp.toISOString().split('T')[0],
        count: item._count.id
      }));

      return {
        total,
        byAction: actionStats,
        byUser: userStats,
        dailyStats,
        period: {
          startDate: filters.startDate,
          endDate: filters.endDate
        }
      };
    } catch (error) {
      console.error('Error fetching audit log stats:', error);
      throw new Error('Failed to fetch audit log statistics');
    }
  }

  /**
   * Get available audit log actions
   */
  static async getAuditLogActions(): Promise<string[]> {
    try {
      const actions = await prisma.auditLog.groupBy({
        by: ['action'],
        _count: {
          action: true
        }
      });

      return actions.map(item => item.action);
    } catch (error) {
      console.error('Error fetching audit log actions:', error);
      return [];
    }
  }

  /**
   * Get user activity summary
   */
  static async getUserActivitySummary(userId: string, days: number): Promise<UserActivitySummary> {
    try {
      const startDate = new Date();
      startDate.setDate(startDate.getDate() - days);

      const where = {
        userId,
        timestamp: {
          gte: startDate
        }
      };

      // Get user details
      const user = await prisma.user.findUnique({
        where: { id: userId },
        select: {
          id: true,
          name: true,
          email: true,
          role: true,
          department: true
        }
      });

      if (!user) {
        throw new Error('User not found');
      }

      // Get activity data
      const [totalActions, actionsByType, recentActions] = await Promise.all([
        prisma.auditLog.count({ where }),
        prisma.auditLog.groupBy({
          by: ['action'],
          where,
          _count: { action: true }
        }),
        prisma.auditLog.findMany({
          where,
          orderBy: { timestamp: 'desc' },
          take: 10,
          select: {
            action: true,
            description: true,
            timestamp: true,
            ipAddress: true
          }
        })
      ]);

      // Process actions by type
      const actionBreakdown = actionsByType.map(item => ({
        action: item.action,
        count: item._count.action
      }));

      return {
        user: {
          id: user.id,
          name: user.name,
          email: user.email,
          role: user.role,
          department: user.department || 'Unassigned'
        },
        period: {
          days,
          startDate: startDate.toISOString(),
          endDate: new Date().toISOString()
        },
        totalActions,
        actionBreakdown,
        recentActions: recentActions.map(action => ({
          action: action.action,
          description: action.description,
          timestamp: action.timestamp,
          ipAddress: action.ipAddress || ''
        }))
      };
    } catch (error) {
      console.error('Error fetching user activity summary:', error);
      throw new Error('Failed to fetch user activity summary');
    }
  }

  /**
   * Get system activity summary
   */
  static async getSystemActivitySummary(days: number): Promise<SystemActivitySummary> {
    try {
      const startDate = new Date();
      startDate.setDate(startDate.getDate() - days);

      const where = {
        timestamp: {
          gte: startDate
        }
      };

      // Get system-wide statistics
      const [totalActions, actionsByType, topUsers, hourlyDistribution] = await Promise.all([
        prisma.auditLog.count({ where }),
        prisma.auditLog.groupBy({
          by: ['action'],
          where,
          _count: { action: true }
        }),
        prisma.auditLog.groupBy({
          by: ['userId'],
          where,
          _count: { userId: true }
        }),
        prisma.auditLog.groupBy({
          by: ['timestamp'],
          where,
          _count: { id: true }
        })
      ]);

      // Process actions by type
      const actionBreakdown = actionsByType.map(item => ({
        action: item.action,
        count: item._count.action
      }));

      // Process top users
      const topUsersList = await Promise.all(
        topUsers.map(async (item) => {
          const user = await prisma.user.findUnique({
            where: { id: item.userId },
            select: { name: true, email: true }
          });
          return {
            userId: item.userId,
            userName: user?.name || 'Unknown',
            userEmail: user?.email || 'Unknown',
            actionCount: item._count.userId
          };
        })
      );

      // Process hourly distribution
      const hourlyStats = hourlyDistribution.map(item => ({
        hour: item.timestamp.getHours(),
        count: item._count.id
      }));

      return {
        period: {
          days,
          startDate: startDate.toISOString(),
          endDate: new Date().toISOString()
        },
        totalActions,
        actionBreakdown,
        topUsers: topUsersList.sort((a, b) => b.actionCount - a.actionCount).slice(0, 10),
        hourlyDistribution: hourlyStats
      };
    } catch (error) {
      console.error('Error fetching system activity summary:', error);
      throw new Error('Failed to fetch system activity summary');
    }
  }

  /**
   * Get audit log dashboard data
   */
  static async getAuditLogDashboard(days: number): Promise<AuditLogDashboard> {
    try {
      const startDate = new Date();
      startDate.setDate(startDate.getDate() - days);

      const where = {
        timestamp: {
          gte: startDate
        }
      };

      // Get dashboard data
      const [totalActions, recentActions, topActions, topUsers] = await Promise.all([
        prisma.auditLog.count({ where }),
        prisma.auditLog.findMany({
          where,
          orderBy: { timestamp: 'desc' },
          take: 5,
          include: {
            user: {
              select: { name: true, email: true }
            }
          }
        }),
        prisma.auditLog.groupBy({
          by: ['action'],
          where,
          _count: { action: true }
        }),
        prisma.auditLog.groupBy({
          by: ['userId'],
          where,
          _count: { userId: true }
        })
      ]);

      // Process recent actions
      const recentActionsList = recentActions.map(action => ({
        id: action.id,
        action: action.action,
        description: action.description,
        userName: action.user?.name || 'Unknown',
        userEmail: action.user?.email || 'Unknown',
        timestamp: action.timestamp
      }));

      // Process top actions
      const topActionsList = topActions
        .map(item => ({
          action: item.action,
          count: item._count.action
        }))
        .sort((a, b) => b.count - a.count)
        .slice(0, 5);

      // Process top users
      const topUsersList = await Promise.all(
        topUsers.slice(0, 5).map(async (item) => {
          const user = await prisma.user.findUnique({
            where: { id: item.userId },
            select: { name: true, email: true }
          });
          return {
            userId: item.userId,
            userName: user?.name || 'Unknown',
            userEmail: user?.email || 'Unknown',
            actionCount: item._count.userId
          };
        })
      );

      return {
        period: {
          days,
          startDate: startDate.toISOString(),
          endDate: new Date().toISOString()
        },
        totalActions,
        recentActions: recentActionsList,
        topActions: topActionsList,
        topUsers: topUsersList
      };
    } catch (error) {
      console.error('Error fetching audit log dashboard:', error);
      throw new Error('Failed to fetch audit log dashboard data');
    }
  }

  /**
   * Create audit log entry
   */
  static async createAuditLog(data: {
    action: string;
    description: string;
    userId: string;
    ipAddress?: string;
    userAgent?: string;
    metadata?: Record<string, any>;
  }): Promise<AuditLog> {
    try {
      const log = await prisma.auditLog.create({
        data: {
          action: data.action,
          description: data.description,
          userId: data.userId,
          userName: 'System', // Default value
          userEmail: 'system@ezifycloud.com', // Default value
          userRole: 'admin', // Default value
          ipAddress: data.ipAddress || '',
          userAgent: data.userAgent || '',
          metadata: data.metadata || {},
          timestamp: new Date()
        },
        include: {
          user: {
            select: {
              id: true,
              name: true,
              email: true,
              role: true
            }
          }
        }
      });

      return {
        id: log.id,
        action: log.action,
        description: log.description,
        userId: log.userId,
        userName: log.user?.name || 'Unknown',
        userEmail: log.user?.email || 'Unknown',
        userRole: log.user?.role || 'Unknown',
        resource: 'system',
        resourceId: log.id,
        ipAddress: log.ipAddress || undefined,
        userAgent: log.userAgent || undefined,
        metadata: log.metadata as Record<string, any> || undefined,
        timestamp: log.timestamp,
        createdAt: log.createdAt
      };
    } catch (error) {
      console.error('Error creating audit log:', error);
      throw new Error('Failed to create audit log');
    }
  }

  /**
   * Export audit logs
   */
  static async exportAuditLogs(filters: {
    format: 'csv' | 'excel' | 'pdf';
    startDate?: string;
    endDate?: string;
    action?: string;
    userId?: string;
  }): Promise<Buffer> {
    try {
      const where: any = {};

      if (filters.startDate) {
        where.timestamp = { ...where.timestamp, gte: new Date(filters.startDate) };
      }

      if (filters.endDate) {
        where.timestamp = { ...where.timestamp, lte: new Date(filters.endDate) };
      }

      if (filters.action) {
        where.action = filters.action;
      }

      if (filters.userId) {
        where.userId = filters.userId;
      }

      // Get audit logs
      const auditLogs = await prisma.auditLog.findMany({
        where,
        include: {
          user: {
            select: {
              name: true,
              email: true,
              role: true
            }
          }
        },
        orderBy: { timestamp: 'desc' }
      });

      // Export functionality placeholder
      // In production, implement actual file generation using:
      // - PDF: puppeteer, jsPDF, or similar
      // - Excel: xlsx, exceljs, or similar  
      // - CSV: csv-writer or similar
      
      const exportData = {
        format: filters.format,
        filters,
        generatedAt: new Date().toISOString(),
        totalRecords: auditLogs.length,
        data: auditLogs.map(log => ({
          id: log.id,
          action: log.action,
          description: log.description,
          userName: log.user?.name || 'Unknown',
          userEmail: log.user?.email || 'Unknown',
          userRole: log.user?.role || 'Unknown',
          ipAddress: log.ipAddress || undefined,
          userAgent: log.userAgent || undefined,
          timestamp: log.timestamp.toISOString(),
          metadata: log.metadata
        }))
      };

      // For now, return a simple JSON buffer
      // In production, generate actual PDF/Excel/CSV files
      return Buffer.from(JSON.stringify(exportData, null, 2));
    } catch (error) {
      console.error('Error exporting audit logs:', error);
      throw new Error('Failed to export audit logs');
    }
  }
}
