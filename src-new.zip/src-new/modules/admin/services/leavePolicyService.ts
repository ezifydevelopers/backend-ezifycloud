import { PrismaClient } from '@prisma/client';
import { 
  LeavePolicy, 
  LeavePolicyFilters, 
  LeavePolicyListResponse, 
  PaginationInfo,
  CreateLeavePolicyData,
  UpdateLeavePolicyData
} from '../types';

const prisma = new PrismaClient();

export class LeavePolicyService {
  /**
   * Get all leave policies with filtering, sorting, and pagination
   */
  static async getLeavePolicies(filters: LeavePolicyFilters): Promise<LeavePolicyListResponse> {
    try {
      const {
        search = '',
        status = 'all',
        leaveType = '',
        page = 1,
        limit = 10,
        sortBy = 'createdAt',
        sortOrder = 'desc'
      } = filters;

      const skip = (page - 1) * limit;

      // Build where clause
      const where: any = {};

      if (search) {
        where.OR = [
          { name: { contains: search, mode: 'insensitive' } },
          { description: { contains: search, mode: 'insensitive' } },
          { leaveType: { contains: search, mode: 'insensitive' } }
        ];
      }

      if (status !== 'all') {
        where.isActive = status === 'active';
      }

      if (leaveType && leaveType !== 'all') {
        where.leaveType = leaveType;
      }

      // Get total count
      const totalCount = await prisma.leavePolicy.count({ where });

      // Get leave policies with pagination
      const policies = await prisma.leavePolicy.findMany({
        where,
        skip,
        take: limit,
        orderBy: { [sortBy]: sortOrder }
      });

      // Transform leave policies
      const transformedPolicies: LeavePolicy[] = policies.map(policy => ({
        id: policy.id,
        name: policy.name,
        description: policy.description || undefined,
        leaveType: policy.leaveType,
        maxDaysPerYear: policy.maxDaysPerYear,
        maxDaysPerRequest: policy.maxDaysPerRequest,
        carryForwardDays: policy.carryForwardDays,
        carryForwardExpiry: policy.carryForwardExpiry,
        requiresApproval: policy.requiresApproval,
        requiresDocumentation: policy.requiresDocumentation,
        isActive: policy.isActive,
        applicableRoles: policy.applicableRoles || [],
        applicableDepartments: policy.applicableDepartments || [],
        createdAt: policy.createdAt,
        updatedAt: policy.updatedAt
      }));

      const totalPages = Math.ceil(totalCount / limit);

      const pagination: PaginationInfo = {
        page,
        limit,
        totalPages,
        totalItems: totalCount,
        hasNext: page < totalPages,
        hasPrev: page > 1
      };

      return {
        policies: transformedPolicies,
        pagination,
        filters,
        totalCount
      };
    } catch (error) {
      console.error('Error fetching leave policies:', error);
      throw new Error('Failed to fetch leave policies');
    }
  }

  /**
   * Get leave policy by ID
   */
  static async getLeavePolicyById(id: string): Promise<LeavePolicy | null> {
    try {
      const policy = await prisma.leavePolicy.findUnique({
        where: { id }
      });

      if (!policy) {
        return null;
      }

      return {
        id: policy.id,
        name: policy.name,
        description: policy.description || undefined,
        leaveType: policy.leaveType,
        maxDaysPerYear: policy.maxDaysPerYear,
        maxDaysPerRequest: policy.maxDaysPerRequest,
        carryForwardDays: policy.carryForwardDays,
        carryForwardExpiry: policy.carryForwardExpiry,
        requiresApproval: policy.requiresApproval,
        requiresDocumentation: policy.requiresDocumentation,
        isActive: policy.isActive,
        applicableRoles: policy.applicableRoles || [],
        applicableDepartments: policy.applicableDepartments || [],
        createdAt: policy.createdAt,
        updatedAt: policy.updatedAt
      };
    } catch (error) {
      console.error('Error fetching leave policy by ID:', error);
      throw new Error('Failed to fetch leave policy');
    }
  }

  /**
   * Create new leave policy
   */
  static async createLeavePolicy(data: CreateLeavePolicyData): Promise<LeavePolicy> {
    try {
      const policy = await prisma.leavePolicy.create({
        data: {
          name: data.name,
          description: data.description,
          leaveType: data.leaveType,
          maxDaysPerYear: data.maxDaysPerYear,
          maxDaysPerRequest: data.maxDaysPerRequest,
          carryForwardDays: data.carryForwardDays,
          carryForwardExpiry: data.carryForwardExpiry,
          requiresApproval: data.requiresApproval,
          requiresDocumentation: data.requiresDocumentation,
          isActive: data.isActive ?? true,
          applicableRoles: data.applicableRoles || [],
          applicableDepartments: data.applicableDepartments || []
        }
      });

      return {
        id: policy.id,
        name: policy.name,
        description: policy.description || undefined,
        leaveType: policy.leaveType,
        maxDaysPerYear: policy.maxDaysPerYear,
        maxDaysPerRequest: policy.maxDaysPerRequest,
        carryForwardDays: policy.carryForwardDays,
        carryForwardExpiry: policy.carryForwardExpiry,
        requiresApproval: policy.requiresApproval,
        requiresDocumentation: policy.requiresDocumentation,
        isActive: policy.isActive,
        applicableRoles: policy.applicableRoles || [],
        applicableDepartments: policy.applicableDepartments || [],
        createdAt: policy.createdAt,
        updatedAt: policy.updatedAt
      };
    } catch (error) {
      console.error('Error creating leave policy:', error);
      throw new Error('Failed to create leave policy');
    }
  }

  /**
   * Update leave policy
   */
  static async updateLeavePolicy(id: string, data: UpdateLeavePolicyData): Promise<LeavePolicy | null> {
    try {
      const policy = await prisma.leavePolicy.update({
        where: { id },
        data: {
          name: data.name,
          description: data.description,
          leaveType: data.leaveType,
          maxDaysPerYear: data.maxDaysPerYear,
          maxDaysPerRequest: data.maxDaysPerRequest,
          carryForwardDays: data.carryForwardDays,
          carryForwardExpiry: data.carryForwardExpiry,
          requiresApproval: data.requiresApproval,
          requiresDocumentation: data.requiresDocumentation,
          isActive: data.isActive,
          applicableRoles: data.applicableRoles,
          applicableDepartments: data.applicableDepartments
        }
      });

      return {
        id: policy.id,
        name: policy.name,
        description: policy.description || undefined,
        leaveType: policy.leaveType,
        maxDaysPerYear: policy.maxDaysPerYear,
        maxDaysPerRequest: policy.maxDaysPerRequest,
        carryForwardDays: policy.carryForwardDays,
        carryForwardExpiry: policy.carryForwardExpiry,
        requiresApproval: policy.requiresApproval,
        requiresDocumentation: policy.requiresDocumentation,
        isActive: policy.isActive,
        applicableRoles: policy.applicableRoles || [],
        applicableDepartments: policy.applicableDepartments || [],
        createdAt: policy.createdAt,
        updatedAt: policy.updatedAt
      };
    } catch (error) {
      console.error('Error updating leave policy:', error);
      throw new Error('Failed to update leave policy');
    }
  }

  /**
   * Delete leave policy
   */
  static async deleteLeavePolicy(id: string): Promise<boolean> {
    try {
      await prisma.leavePolicy.delete({
        where: { id }
      });
      return true;
    } catch (error) {
      console.error('Error deleting leave policy:', error);
      throw new Error('Failed to delete leave policy');
    }
  }

  /**
   * Toggle leave policy status
   */
  static async toggleLeavePolicyStatus(id: string, isActive: boolean): Promise<LeavePolicy | null> {
    try {
      const policy = await prisma.leavePolicy.update({
        where: { id },
        data: { isActive }
      });

      return {
        id: policy.id,
        name: policy.name,
        description: policy.description || undefined,
        leaveType: policy.leaveType,
        maxDaysPerYear: policy.maxDaysPerYear,
        maxDaysPerRequest: policy.maxDaysPerRequest,
        carryForwardDays: policy.carryForwardDays,
        carryForwardExpiry: policy.carryForwardExpiry,
        requiresApproval: policy.requiresApproval,
        requiresDocumentation: policy.requiresDocumentation,
        isActive: policy.isActive,
        applicableRoles: policy.applicableRoles || [],
        applicableDepartments: policy.applicableDepartments || [],
        createdAt: policy.createdAt,
        updatedAt: policy.updatedAt
      };
    } catch (error) {
      console.error('Error toggling leave policy status:', error);
      throw new Error('Failed to toggle leave policy status');
    }
  }

  /**
   * Get leave policy statistics
   */
  static async getLeavePolicyStats(): Promise<{
    total: number;
    active: number;
    inactive: number;
    byLeaveType: { [key: string]: number };
  }> {
    try {
      const [total, active, inactive] = await Promise.all([
        prisma.leavePolicy.count(),
        prisma.leavePolicy.count({ where: { isActive: true } }),
        prisma.leavePolicy.count({ where: { isActive: false } })
      ]);

      // Get by leave type
      const byLeaveType = await prisma.leavePolicy.groupBy({
        by: ['leaveType'],
        _count: {
          leaveType: true
        }
      });

      const leaveTypeStats: { [key: string]: number } = {};
      byLeaveType.forEach(item => {
        leaveTypeStats[item.leaveType] = item._count.leaveType;
      });

      return {
        total,
        active,
        inactive,
        byLeaveType: leaveTypeStats
      };
    } catch (error) {
      console.error('Error fetching leave policy stats:', error);
      throw new Error('Failed to fetch leave policy statistics');
    }
  }

  /**
   * Get leave policy types
   */
  static async getLeavePolicyTypes(): Promise<string[]> {
    try {
      const leaveTypes = await prisma.leavePolicy.groupBy({
        by: ['leaveType'],
        _count: {
          leaveType: true
        }
      });

      return leaveTypes.map(item => item.leaveType);
    } catch (error) {
      console.error('Error fetching leave policy types:', error);
      return [];
    }
  }

  /**
   * Bulk update leave policies
   */
  static async bulkUpdateLeavePolicies(
    policyIds: string[],
    updates: Partial<UpdateLeavePolicyData>
  ): Promise<{ updated: number; failed: number }> {
    try {
      let updated = 0;
      let failed = 0;

      for (const id of policyIds) {
        try {
          await prisma.leavePolicy.update({
            where: { id },
            data: updates
          });
          updated++;
        } catch (error) {
          console.error(`Error updating leave policy ${id}:`, error);
          failed++;
        }
      }

      return { updated, failed };
    } catch (error) {
      console.error('Error bulk updating leave policies:', error);
      throw new Error('Failed to bulk update leave policies');
    }
  }
}
