import { PrismaClient } from '@prisma/client';
import { 
  CompanySettings,
  LeaveSettings,
  NotificationSettings,
  SecuritySettings,
  SystemConfigSettings,
  SettingsHistory
} from '../types';

const prisma = new PrismaClient();

export class SettingsService {
  /**
   * Get all system settings
   */
  static async getAllSettings(): Promise<{
    company: CompanySettings;
    leave: LeaveSettings;
    notification: NotificationSettings;
    security: SecuritySettings;
    systemConfig: SystemConfigSettings;
  }> {
    try {
      const [company, leave, notification, security, systemConfig] = await Promise.all([
        this.getCompanySettings(),
        this.getLeaveSettings(),
        this.getNotificationSettings(),
        this.getSecuritySettings(),
        this.getSystemConfigSettings()
      ]);

      return {
        company,
        leave,
        notification,
        security,
        systemConfig
      };
    } catch (error) {
      console.error('Error fetching all settings:', error);
      throw new Error('Failed to fetch all settings');
    }
  }

  /**
   * Get company settings
   */
  static async getCompanySettings(): Promise<CompanySettings> {
    try {
      const settings = await prisma.systemSettings.findMany({
        where: { category: 'company', isActive: true }
      });

      // Convert array of settings to object
      const companySettings: any = {};
      settings.forEach(setting => {
        companySettings[setting.key] = setting.value;
      });

      // Return with defaults if no settings found
      return {
        name: companySettings.name || 'Ezify Cloud',
        email: companySettings.email || 'admin@ezifycloud.com',
        phone: companySettings.phone || '+1-555-0123',
        address: companySettings.address || '123 Business St, City, State 12345',
        website: companySettings.website || 'https://ezifycloud.com',
        logo: companySettings.logo || '/assets/logo.png',
        timezone: companySettings.timezone || 'UTC',
        dateFormat: companySettings.dateFormat || 'MM/DD/YYYY',
        currency: companySettings.currency || 'USD',
        language: companySettings.language || 'en'
      };
    } catch (error) {
      console.error('Error fetching company settings:', error);
      throw new Error('Failed to fetch company settings');
    }
  }

  /**
   * Update company settings
   */
  static async updateCompanySettings(data: Partial<CompanySettings>, userId?: string): Promise<CompanySettings> {
    try {
      const currentSettings = await this.getCompanySettings();
      const updatedSettings = { ...currentSettings, ...data };
      
      // Update each setting in the database
      for (const [key, value] of Object.entries(data)) {
        if (value !== undefined) {
          await prisma.systemSettings.upsert({
            where: {
              category_key: {
                category: 'company',
                key: key
              }
            },
            update: {
              value: value,
              updatedAt: new Date()
            },
            create: {
              category: 'company',
              key: key,
              value: value,
              description: `Company ${key} setting`
            }
          });

          // Log the change if userId is provided
          if (userId) {
            await this.logSettingsChange('company', key, currentSettings[key as keyof CompanySettings], value, userId);
          }
        }
      }
      
      return updatedSettings;
    } catch (error) {
      console.error('Error updating company settings:', error);
      throw new Error('Failed to update company settings');
    }
  }

  /**
   * Get leave settings
   */
  static async getLeaveSettings(): Promise<LeaveSettings> {
    try {
      // In a real application, this would fetch from a settings table
      return {
        defaultLeaveDays: 20,
        maxLeaveDays: 30,
        carryForwardDays: 5,
        maxCarryForwardDays: 10,
        requireManagerApproval: true,
        allowHalfDayLeave: true,
        maxConsecutiveDays: 10,
        advanceNoticeDays: 2,
        defaultAnnualLeave: 20,
        defaultSickLeave: 10,
        defaultCasualLeave: 5,
        allowCarryForward: true
      };
    } catch (error) {
      console.error('Error fetching leave settings:', error);
      throw new Error('Failed to fetch leave settings');
    }
  }

  /**
   * Update leave settings
   */
  static async updateLeaveSettings(data: Partial<LeaveSettings>): Promise<LeaveSettings> {
    try {
      const currentSettings = await this.getLeaveSettings();
      const updatedSettings = { ...currentSettings, ...data };
      
      // Log the change
      await this.logSettingsChange('leave', 'leave_settings', currentSettings, updatedSettings, 'system');
      
      return updatedSettings;
    } catch (error) {
      console.error('Error updating leave settings:', error);
      throw new Error('Failed to update leave settings');
    }
  }

  /**
   * Get notification settings
   */
  static async getNotificationSettings(): Promise<NotificationSettings> {
    try {
      return {
        emailNotifications: true,
        smsNotifications: false,
        pushNotifications: true,
        notifyOnNewRequest: true,
        notifyOnApproval: true,
        notifyOnRejection: true,
        notifyOnReminder: true,
        notifyOnSystemUpdate: true
      };
    } catch (error) {
      console.error('Error fetching notification settings:', error);
      throw new Error('Failed to fetch notification settings');
    }
  }

  /**
   * Update notification settings
   */
  static async updateNotificationSettings(data: Partial<NotificationSettings>): Promise<NotificationSettings> {
    try {
      const currentSettings = await this.getNotificationSettings();
      const updatedSettings = { ...currentSettings, ...data };
      
      // Log the change
      await this.logSettingsChange('notification', 'notification_settings', currentSettings, updatedSettings, 'system');
      
      return updatedSettings;
    } catch (error) {
      console.error('Error updating notification settings:', error);
      throw new Error('Failed to update notification settings');
    }
  }

  /**
   * Get security settings
   */
  static async getSecuritySettings(): Promise<SecuritySettings> {
    try {
      return {
        sessionTimeout: 30, // minutes
        requireTwoFactor: false,
        passwordExpiry: 90, // days
        maxLoginAttempts: 5,
        lockoutDuration: 15, // minutes
        enableAuditLogs: true,
        dataRetentionDays: 365
      };
    } catch (error) {
      console.error('Error fetching security settings:', error);
      throw new Error('Failed to fetch security settings');
    }
  }

  /**
   * Update security settings
   */
  static async updateSecuritySettings(data: Partial<SecuritySettings>): Promise<SecuritySettings> {
    try {
      const currentSettings = await this.getSecuritySettings();
      const updatedSettings = { ...currentSettings, ...data };
      
      // Log the change
      await this.logSettingsChange('security', 'security_settings', currentSettings, updatedSettings, 'system');
      
      return updatedSettings;
    } catch (error) {
      console.error('Error updating security settings:', error);
      throw new Error('Failed to update security settings');
    }
  }

  /**
   * Get system configuration settings
   */
  static async getSystemConfigSettings(): Promise<SystemConfigSettings> {
    try {
      return {
        maintenanceMode: false,
        autoBackup: true,
        backupFrequency: 'daily',
        logRetentionDays: 30,
        systemVersion: '1.0.0',
        lastUpdate: new Date().toISOString()
      };
    } catch (error) {
      console.error('Error fetching system config settings:', error);
      throw new Error('Failed to fetch system configuration settings');
    }
  }

  /**
   * Update system configuration settings
   */
  static async updateSystemConfigSettings(data: Partial<SystemConfigSettings>): Promise<SystemConfigSettings> {
    try {
      const currentSettings = await this.getSystemConfigSettings();
      const updatedSettings = { ...currentSettings, ...data };
      
      // Log the change
      await this.logSettingsChange('system_config', 'system_config_settings', currentSettings, updatedSettings, 'system');
      
      return updatedSettings;
    } catch (error) {
      console.error('Error updating system config settings:', error);
      throw new Error('Failed to update system configuration settings');
    }
  }

  /**
   * Reset settings to default
   */
  static async resetSettingsToDefault(category?: string): Promise<any> {
    try {
      const defaultSettings = {
        company: {
          name: 'Ezify Cloud',
          email: 'admin@ezifycloud.com',
          phone: '+1-555-0123',
          address: '123 Business St, City, State 12345',
          website: 'https://ezifycloud.com',
          logo: '/assets/logo.png',
          timezone: 'UTC',
          dateFormat: 'MM/DD/YYYY',
          currency: 'USD',
          language: 'en'
        },
        leave: {
          defaultLeaveDays: 20,
          maxLeaveDays: 30,
          carryForwardDays: 5,
          maxCarryForwardDays: 10,
          requireManagerApproval: true,
          allowHalfDayLeave: true,
          maxConsecutiveDays: 10,
          advanceNoticeDays: 2
        },
        notification: {
          emailNotifications: true,
          smsNotifications: false,
          pushNotifications: true,
          notifyOnNewRequest: true,
          notifyOnApproval: true,
          notifyOnRejection: true,
          notifyOnReminder: true,
          notifyOnSystemUpdate: true
        },
        security: {
          sessionTimeout: 30,
          requireTwoFactor: false,
          passwordExpiry: 90,
          maxLoginAttempts: 5,
          lockoutDuration: 15,
          enableAuditLogs: true,
          dataRetentionDays: 365
        },
        systemConfig: {
          maintenanceMode: false,
          autoBackup: true,
          backupFrequency: 'daily',
          logRetentionDays: 30,
          systemVersion: '1.0.0',
          lastUpdate: new Date().toISOString()
        }
      };

      if (category && defaultSettings[category as keyof typeof defaultSettings]) {
        const resetSettings = defaultSettings[category as keyof typeof defaultSettings];
        await this.logSettingsChange(category, `${category}_settings`, {}, resetSettings, 'system');
        return resetSettings;
      } else {
        // Reset all settings
        for (const [cat, settings] of Object.entries(defaultSettings)) {
          await this.logSettingsChange(cat, `${cat}_settings`, {}, settings, 'system');
        }
        return defaultSettings;
      }
    } catch (error) {
      console.error('Error resetting settings to default:', error);
      throw new Error('Failed to reset settings to default');
    }
  }

  /**
   * Export settings
   */
  static async exportSettings(format: string): Promise<Buffer> {
    try {
      const settings = await this.getAllSettings();
      
      let exportData: string;
      
      switch (format.toLowerCase()) {
        case 'yaml':
          // In a real application, use a YAML library
          exportData = JSON.stringify(settings, null, 2);
          break;
        case 'csv':
          // In a real application, convert to CSV format
          exportData = JSON.stringify(settings, null, 2);
          break;
        case 'json':
        default:
          exportData = JSON.stringify(settings, null, 2);
          break;
      }

      return Buffer.from(exportData);
    } catch (error) {
      console.error('Error exporting settings:', error);
      throw new Error('Failed to export settings');
    }
  }

  /**
   * Import settings
   */
  static async importSettings(data: any): Promise<{
    imported: number;
    errors: string[];
  }> {
    try {
      let imported = 0;
      const errors: string[] = [];

      // Validate and import each category
      const categories = ['company', 'leave', 'notification', 'security', 'systemConfig'];
      
      for (const category of categories) {
        if (data[category]) {
          try {
            await this.logSettingsChange(category, `${category}_settings`, {}, data[category], 'system');
            imported++;
          } catch (error) {
            errors.push(`Failed to import ${category}: ${error instanceof Error ? error.message : 'Unknown error'}`);
          }
        }
      }

      return { imported, errors };
    } catch (error) {
      console.error('Error importing settings:', error);
      throw new Error('Failed to import settings');
    }
  }

  /**
   * Get settings history
   */
  static async getSettingsHistory(
    category: string,
    page: number = 1,
    limit: number = 10
  ): Promise<{
    history: SettingsHistory[];
    pagination: {
      page: number;
      limit: number;
      totalPages: number;
      totalItems: number;
      hasNext: boolean;
      hasPrev: boolean;
    };
  }> {
    try {
      // In a real application, this would fetch from a settings_history table
      // For now, return empty data as settings history is not yet implemented
      const history: SettingsHistory[] = [];

      const totalItems = history.length;
      const totalPages = Math.ceil(totalItems / limit);
      const skip = (page - 1) * limit;

      return {
        history: history.slice(skip, skip + limit),
        pagination: {
          page,
          limit,
          totalPages,
          totalItems,
          hasNext: page < totalPages,
          hasPrev: page > 1
        }
      };
    } catch (error) {
      console.error('Error fetching settings history:', error);
      throw new Error('Failed to fetch settings history');
    }
  }

  /**
   * Log settings change (internal method)
   */
  private static async logSettingsChange(
    category: string, 
    key: string, 
    oldValue: any, 
    newValue: any, 
    userId: string
  ): Promise<void> {
    try {
      await prisma.settingsHistory.create({
        data: {
          category,
          key,
          oldValue,
          newValue,
          changedBy: userId,
          reason: `Updated ${category} ${key} setting`
        }
      });
      console.log(`Settings change logged: ${category}.${key} by user ${userId}`);
    } catch (error) {
      console.error('Error logging settings change:', error);
      // Don't throw error here as it's not critical
    }
  }
}
