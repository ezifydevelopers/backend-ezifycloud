import { PrismaClient } from '@prisma/client';
import { 
  LeaveTrendsData,
  DepartmentStatsData,
  LeaveBalanceReport,
  EmployeeLeaveSummary,
  LeaveUtilizationReport,
  MonthlyLeaveReport,
  ReportDashboard,
  ReportType
} from '../types';

const prisma = new PrismaClient();

export class ReportsService {
  /**
   * Get leave trends data for charts
   */
  static async getLeaveTrends(filters: {
    startDate: string;
    endDate: string;
    department?: string;
    leaveType?: string;
  }): Promise<LeaveTrendsData> {
    try {
      const where: any = {
        createdAt: {
          gte: new Date(filters.startDate),
          lte: new Date(filters.endDate)
        }
      };

      if (filters.department) {
        where.user = { department: filters.department };
      }

      if (filters.leaveType) {
        where.leaveType = filters.leaveType;
      }

      // Get monthly trends
      const monthlyData = await prisma.leaveRequest.groupBy({
        by: ['createdAt'],
        where,
        _count: {
          id: true
        },
        _sum: {
          totalDays: true
        }
      });

      // Get leave type distribution
      const leaveTypeData = await prisma.leaveRequest.groupBy({
        by: ['leaveType'],
        where,
        _count: {
          leaveType: true
        }
      });

      // Get status distribution
      const statusData = await prisma.leaveRequest.groupBy({
        by: ['status'],
        where,
        _count: {
          status: true
        }
      });

      // Process monthly data
      const monthlyTrends = monthlyData.map(item => ({
        month: item.createdAt.toISOString().substring(0, 7), // YYYY-MM format
        totalRequests: item._count.id,
        totalDays: Number(item._sum.totalDays) || 0
      }));

      // Process leave type data
      const leaveTypeDistribution = leaveTypeData.map(item => ({
        leaveType: item.leaveType,
        count: item._count.leaveType
      }));

      // Process status data
      const statusDistribution = statusData.map(item => ({
        status: item.status,
        count: item._count.status
      }));

      return {
        monthlyTrends,
        leaveTypeDistribution,
        statusDistribution,
        totalRequests: monthlyTrends.reduce((sum, item) => sum + item.totalRequests, 0),
        totalDays: monthlyTrends.reduce((sum, item) => sum + item.totalDays, 0)
      };
    } catch (error) {
      console.error('Error fetching leave trends:', error);
      throw new Error('Failed to fetch leave trends');
    }
  }

  /**
   * Get department statistics
   */
  static async getDepartmentStats(filters: {
    startDate: string;
    endDate: string;
  }): Promise<DepartmentStatsData[]> {
    try {
      const where: any = {
        createdAt: {
          gte: new Date(filters.startDate),
          lte: new Date(filters.endDate)
        }
      };

      // Get department-wise statistics
      const departmentStats = await prisma.leaveRequest.groupBy({
        by: ['userId'],
        where,
        _count: {
          id: true
        },
        _sum: {
          totalDays: true
        }
      });

      // Get user details for each department
      const statsWithDetails = await Promise.all(
        departmentStats.map(async (stat) => {
          const user = await prisma.user.findUnique({
            where: { id: stat.userId },
            select: { department: true, name: true }
          });

          return {
            department: user?.department || 'Unassigned',
            totalRequests: stat._count.id,
            totalDays: Number(stat._sum.totalDays) || 0,
            employeeName: user?.name || 'Unknown'
          };
        })
      );

      // Group by department
      const groupedStats = statsWithDetails.reduce((acc, stat) => {
        const dept = stat.department;
        if (!acc[dept]) {
          acc[dept] = {
            department: dept,
            totalEmployees: 0,
            totalRequests: 0,
            totalDays: 0,
            averageDaysPerEmployee: 0
          };
        }
        acc[dept].totalEmployees++;
        acc[dept].totalRequests += stat.totalRequests;
        acc[dept].totalDays += stat.totalDays;
        return acc;
      }, {} as Record<string, any>);

      // Calculate averages
      Object.values(groupedStats).forEach((stat: any) => {
        stat.averageDaysPerEmployee = stat.totalEmployees > 0 
          ? Math.round((stat.totalDays / stat.totalEmployees) * 100) / 100 
          : 0;
      });

      return Object.values(groupedStats);
    } catch (error) {
      console.error('Error fetching department stats:', error);
      throw new Error('Failed to fetch department statistics');
    }
  }

  /**
   * Get leave balance report
   */
  static async getLeaveBalanceReport(filters: {
    department?: string;
    year: number;
  }): Promise<LeaveBalanceReport[]> {
    try {
      const where: any = {
        year: filters.year
      };

      if (filters.department) {
        where.user = { department: filters.department };
      }

      // Get leave balances
      const balances = await prisma.leaveBalance.findMany({
        where,
        include: {
          user: {
            select: {
              id: true,
              name: true,
              email: true,
              department: true
            }
          }
        }
      });

      return balances.map(balance => ({
        employeeId: balance.userId,
        employeeName: balance.user.name,
        employeeEmail: balance.user.email,
        department: balance.user.department || 'Unassigned',
        leaveType: 'annual', // Default to annual for now
        totalDays: balance.annualTotal,
        usedDays: balance.annualUsed,
        remainingDays: balance.annualRemaining,
        carryForwardDays: 0, // Not available in new structure
        year: balance.year
      }));
    } catch (error) {
      console.error('Error fetching leave balance report:', error);
      throw new Error('Failed to fetch leave balance report');
    }
  }

  /**
   * Get employee leave summary
   */
  static async getEmployeeLeaveSummary(filters: {
    employeeId: string;
    year: number;
  }): Promise<EmployeeLeaveSummary> {
    try {
      const where = {
        userId: filters.employeeId,
        createdAt: {
          gte: new Date(`${filters.year}-01-01`),
          lte: new Date(`${filters.year}-12-31`)
        }
      };

      // Get employee details
      const employee = await prisma.user.findUnique({
        where: { id: filters.employeeId },
        select: {
          id: true,
          name: true,
          email: true,
          department: true
        }
      });

      if (!employee) {
        throw new Error('Employee not found');
      }

      // Get leave requests
      const leaveRequests = await prisma.leaveRequest.findMany({
        where,
        orderBy: { createdAt: 'desc' }
      });

      // Get leave balances
      const leaveBalances = await prisma.leaveBalance.findMany({
        where: {
          userId: filters.employeeId,
          year: filters.year
        }
      });

      // Calculate summary
      const summary = {
        employee: {
          id: employee.id,
          name: employee.name,
          email: employee.email,
          department: employee.department || 'Unassigned'
        },
        year: filters.year,
        totalRequests: leaveRequests.length,
        approvedRequests: leaveRequests.filter(r => r.status === 'approved').length,
        rejectedRequests: leaveRequests.filter(r => r.status === 'rejected').length,
        pendingRequests: leaveRequests.filter(r => r.status === 'pending').length,
        totalDaysRequested: leaveRequests.reduce((sum, r) => sum + Number(r.totalDays), 0),
        totalDaysApproved: leaveRequests
          .filter(r => r.status === 'approved')
          .reduce((sum, r) => sum + Number(r.totalDays), 0),
        leaveBalances: leaveBalances.map(balance => ({
          leaveType: 'annual', // Default to annual for now
          totalDays: balance.annualTotal,
          usedDays: balance.annualUsed,
          remainingDays: balance.annualRemaining,
          carryForwardDays: 0 // Not available in new structure
        })),
        recentRequests: leaveRequests.slice(0, 5).map(request => ({
          id: request.id,
          leaveType: request.leaveType,
          startDate: request.startDate,
          endDate: request.endDate,
          days: Number(request.totalDays),
          status: request.status,
          submittedAt: request.submittedAt
        }))
      };

      return summary;
    } catch (error) {
      console.error('Error fetching employee leave summary:', error);
      throw new Error('Failed to fetch employee leave summary');
    }
  }

  /**
   * Get leave utilization report
   */
  static async getLeaveUtilizationReport(filters: {
    startDate: string;
    endDate: string;
    department?: string;
    leaveType?: string;
  }): Promise<LeaveUtilizationReport> {
    try {
      const where: any = {
        createdAt: {
          gte: new Date(filters.startDate),
          lte: new Date(filters.endDate)
        }
      };

      if (filters.department) {
        where.user = { department: filters.department };
      }

      if (filters.leaveType) {
        where.leaveType = filters.leaveType;
      }

      // Get utilization data
      const utilizationData = await prisma.leaveRequest.groupBy({
        by: ['leaveType'],
        where,
        _count: {
          id: true
        },
        _sum: {
          totalDays: true
        }
      });

      // Get total employees for calculation
      const totalEmployees = await prisma.user.count({
        where: filters.department ? { department: filters.department } : {}
      });

      const utilization = utilizationData.map(item => {
        const totalDays = Number(item._sum.totalDays) || 0;
        const totalRequests = item._count.id;
        const averageDaysPerRequest = totalRequests > 0 ? totalDays / totalRequests : 0;
        const utilizationRate = totalEmployees > 0 ? (totalRequests / totalEmployees) * 100 : 0;

        return {
          leaveType: item.leaveType,
          totalRequests,
          totalDays,
          averageDaysPerRequest: Math.round(averageDaysPerRequest * 100) / 100,
          utilizationRate: Math.round(utilizationRate * 100) / 100
        };
      });

      return {
        utilization,
        totalEmployees,
        period: {
          startDate: filters.startDate,
          endDate: filters.endDate
        }
      };
    } catch (error) {
      console.error('Error fetching leave utilization report:', error);
      throw new Error('Failed to fetch leave utilization report');
    }
  }

  /**
   * Get monthly leave report
   */
  static async getMonthlyLeaveReport(filters: {
    year: number;
    month: number;
    department?: string;
  }): Promise<MonthlyLeaveReport> {
    try {
      const startDate = new Date(filters.year, filters.month - 1, 1);
      const endDate = new Date(filters.year, filters.month, 0);

      const where: any = {
        createdAt: {
          gte: startDate,
          lte: endDate
        }
      };

      if (filters.department) {
        where.user = { department: filters.department };
      }

      // Get monthly data
      const monthlyData = await prisma.leaveRequest.findMany({
        where,
        include: {
          user: {
            select: {
              name: true,
              department: true
            }
          }
        }
      });

      // Process data
      const summary = {
    year: filters.year,
    month: filters.month,
    totalRequests: monthlyData.length,
    approvedRequests: monthlyData.filter(r => r.status === 'approved').length,
    rejectedRequests: monthlyData.filter(r => r.status === 'rejected').length,
    pendingRequests: monthlyData.filter(r => r.status === 'pending').length,
    totalDays: monthlyData.reduce((sum, r) => sum + Number(r.totalDays), 0),
    averageDaysPerRequest: monthlyData.length > 0 
      ? Math.round((monthlyData.reduce((sum, r) => sum + Number(r.totalDays), 0) / monthlyData.length) * 100) / 100 
      : 0
  };

      // Group by department
      const departmentBreakdown = monthlyData.reduce((acc, request) => {
        const dept = request.user.department || 'Unassigned';
        if (!acc[dept]) {
          acc[dept] = {
            department: dept,
            totalRequests: 0,
            totalDays: 0
          };
        }
        acc[dept].totalRequests++;
        acc[dept].totalDays += Number(request.totalDays);
        return acc;
      }, {} as Record<string, any>);

      return {
        summary,
        departmentBreakdown: Object.values(departmentBreakdown),
        requests: monthlyData.map(request => ({
          id: request.id,
          employeeName: request.user.name,
          department: request.user.department || 'Unassigned',
          leaveType: request.leaveType,
          startDate: request.startDate,
          endDate: request.endDate,
          days: Number(request.totalDays),
          status: request.status,
          submittedAt: request.submittedAt
        }))
      };
    } catch (error) {
      console.error('Error fetching monthly leave report:', error);
      throw new Error('Failed to fetch monthly leave report');
    }
  }

  /**
   * Get report dashboard data
   */
  static async getReportDashboard(year: number): Promise<ReportDashboard> {
    try {
      const startDate = new Date(`${year}-01-01`);
      const endDate = new Date(`${year}-12-31`);

      // Get basic stats
      const [totalRequests, totalEmployees, totalDays] = await Promise.all([
        prisma.leaveRequest.count({
          where: {
            createdAt: { gte: startDate, lte: endDate }
          }
        }),
        prisma.user.count(),
        prisma.leaveRequest.aggregate({
          where: {
            createdAt: { gte: startDate, lte: endDate }
          },
          _sum: { totalDays: true }
        })
      ]);

      // Get top departments by leave usage
      const topDepartments = await prisma.leaveRequest.groupBy({
        by: ['userId'],
        where: {
          createdAt: { gte: startDate, lte: endDate }
        },
        _sum: { totalDays: true }
      });

      // Get department names
      const departmentStats = await Promise.all(
        topDepartments.map(async (stat) => {
          const user = await prisma.user.findUnique({
            where: { id: stat.userId },
            select: { department: true }
          });
          return {
            department: user?.department || 'Unassigned',
            totalDays: Number(stat._sum.totalDays) || 0
          };
        })
      );

      // Group by department
      const groupedDepts = departmentStats.reduce((acc, stat) => {
        const dept = stat.department;
        if (!acc[dept]) {
          acc[dept] = 0;
        }
        acc[dept] += stat.totalDays;
        return acc;
      }, {} as Record<string, number>);

      const topDepartmentsList = Object.entries(groupedDepts)
        .map(([department, totalDays]) => ({ department, totalDays }))
        .sort((a, b) => b.totalDays - a.totalDays)
        .slice(0, 5);

      return {
        year,
        totalRequests,
        totalEmployees,
        totalDays: Number(totalDays._sum.totalDays) || 0,
        averageDaysPerEmployee: totalEmployees > 0 
          ? Math.round(((Number(totalDays._sum.totalDays) || 0) / totalEmployees) * 100) / 100 
          : 0,
        topDepartments: topDepartmentsList
      };
    } catch (error) {
      console.error('Error fetching report dashboard:', error);
      throw new Error('Failed to fetch report dashboard data');
    }
  }

  /**
   * Get available report types
   */
  static async getAvailableReportTypes(): Promise<ReportType[]> {
    try {
      return [
        {
          id: 'leave-trends',
          name: 'Leave Trends',
          description: 'Monthly leave request trends and patterns',
          category: 'Analytics'
        },
        {
          id: 'department-stats',
          name: 'Department Statistics',
          description: 'Leave usage statistics by department',
          category: 'Department'
        },
        {
          id: 'leave-balance',
          name: 'Leave Balance Report',
          description: 'Current leave balances for all employees',
          category: 'Balance'
        },
        {
          id: 'employee-summary',
          name: 'Employee Leave Summary',
          description: 'Individual employee leave history and summary',
          category: 'Employee'
        },
        {
          id: 'utilization',
          name: 'Leave Utilization Report',
          description: 'Leave utilization rates and patterns',
          category: 'Analytics'
        },
        {
          id: 'monthly-report',
          name: 'Monthly Leave Report',
          description: 'Detailed monthly leave report',
          category: 'Monthly'
        }
      ];
    } catch (error) {
      console.error('Error fetching available report types:', error);
      return [];
    }
  }

  /**
   * Export report data
   */
  static async exportReport(filters: {
    reportType: string;
    format: 'pdf' | 'excel' | 'csv';
    startDate: string;
    endDate: string;
    department?: string;
  }): Promise<Buffer> {
    try {
      // Export functionality placeholder
      // In production, implement actual file generation using:
      // - PDF: puppeteer, jsPDF, or similar
      // - Excel: xlsx, exceljs, or similar  
      // - CSV: csv-writer or similar
      
      const reportData = {
        reportType: filters.reportType,
        period: {
          startDate: filters.startDate,
          endDate: filters.endDate
        },
        department: filters.department,
        generatedAt: new Date().toISOString()
      };

      // For now, return a simple JSON buffer
      // In production, generate actual PDF/Excel/CSV files
      return Buffer.from(JSON.stringify(reportData, null, 2));
    } catch (error) {
      console.error('Error exporting report:', error);
      throw new Error('Failed to export report');
    }
  }
}
