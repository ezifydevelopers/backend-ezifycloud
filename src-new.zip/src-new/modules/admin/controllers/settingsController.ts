import { Request, Response } from 'express';
import { SettingsService } from '../services/settingsService';
import { ApiResponse } from '../types';

export class SettingsController {
  /**
   * Get all system settings
   */
  static async getAllSettings(req: Request, res: Response): Promise<void> {
    try {
      const settings = await SettingsService.getAllSettings();
      
      const response: ApiResponse = {
        success: true,
        message: 'Settings retrieved successfully',
        data: settings
      };

      res.status(200).json(response);
    } catch (error) {
      console.error('Error fetching settings:', error);
      const response: ApiResponse = {
        success: false,
        message: 'Failed to fetch settings',
        error: error instanceof Error ? error.message : 'Unknown error'
      };
      res.status(500).json(response);
    }
  }

  /**
   * Get company settings
   */
  static async getCompanySettings(req: Request, res: Response): Promise<void> {
    try {
      const settings = await SettingsService.getCompanySettings();
      
      const response: ApiResponse = {
        success: true,
        message: 'Company settings retrieved successfully',
        data: settings
      };

      res.status(200).json(response);
    } catch (error) {
      console.error('Error fetching company settings:', error);
      const response: ApiResponse = {
        success: false,
        message: 'Failed to fetch company settings',
        error: error instanceof Error ? error.message : 'Unknown error'
      };
      res.status(500).json(response);
    }
  }

  /**
   * Update company settings
   */
  static async updateCompanySettings(req: Request, res: Response): Promise<void> {
    try {
      const settingsData = req.body;
      const userId = (req as any).user?.id; // Get user ID from auth middleware
      
      const settings = await SettingsService.updateCompanySettings(settingsData, userId);
      
      const response: ApiResponse = {
        success: true,
        message: 'Company settings updated successfully',
        data: settings
      };

      res.status(200).json(response);
    } catch (error) {
      console.error('Error updating company settings:', error);
      const response: ApiResponse = {
        success: false,
        message: 'Failed to update company settings',
        error: error instanceof Error ? error.message : 'Unknown error'
      };
      res.status(500).json(response);
    }
  }

  /**
   * Get leave settings
   */
  static async getLeaveSettings(req: Request, res: Response): Promise<void> {
    try {
      const settings = await SettingsService.getLeaveSettings();
      
      const response: ApiResponse = {
        success: true,
        message: 'Leave settings retrieved successfully',
        data: settings
      };

      res.status(200).json(response);
    } catch (error) {
      console.error('Error fetching leave settings:', error);
      const response: ApiResponse = {
        success: false,
        message: 'Failed to fetch leave settings',
        error: error instanceof Error ? error.message : 'Unknown error'
      };
      res.status(500).json(response);
    }
  }

  /**
   * Update leave settings
   */
  static async updateLeaveSettings(req: Request, res: Response): Promise<void> {
    try {
      const settingsData = req.body;
      
      const settings = await SettingsService.updateLeaveSettings(settingsData);
      
      const response: ApiResponse = {
        success: true,
        message: 'Leave settings updated successfully',
        data: settings
      };

      res.status(200).json(response);
    } catch (error) {
      console.error('Error updating leave settings:', error);
      const response: ApiResponse = {
        success: false,
        message: 'Failed to update leave settings',
        error: error instanceof Error ? error.message : 'Unknown error'
      };
      res.status(500).json(response);
    }
  }

  /**
   * Get notification settings
   */
  static async getNotificationSettings(req: Request, res: Response): Promise<void> {
    try {
      const settings = await SettingsService.getNotificationSettings();
      
      const response: ApiResponse = {
        success: true,
        message: 'Notification settings retrieved successfully',
        data: settings
      };

      res.status(200).json(response);
    } catch (error) {
      console.error('Error fetching notification settings:', error);
      const response: ApiResponse = {
        success: false,
        message: 'Failed to fetch notification settings',
        error: error instanceof Error ? error.message : 'Unknown error'
      };
      res.status(500).json(response);
    }
  }

  /**
   * Update notification settings
   */
  static async updateNotificationSettings(req: Request, res: Response): Promise<void> {
    try {
      const settingsData = req.body;
      
      const settings = await SettingsService.updateNotificationSettings(settingsData);
      
      const response: ApiResponse = {
        success: true,
        message: 'Notification settings updated successfully',
        data: settings
      };

      res.status(200).json(response);
    } catch (error) {
      console.error('Error updating notification settings:', error);
      const response: ApiResponse = {
        success: false,
        message: 'Failed to update notification settings',
        error: error instanceof Error ? error.message : 'Unknown error'
      };
      res.status(500).json(response);
    }
  }

  /**
   * Get security settings
   */
  static async getSecuritySettings(req: Request, res: Response): Promise<void> {
    try {
      const settings = await SettingsService.getSecuritySettings();
      
      const response: ApiResponse = {
        success: true,
        message: 'Security settings retrieved successfully',
        data: settings
      };

      res.status(200).json(response);
    } catch (error) {
      console.error('Error fetching security settings:', error);
      const response: ApiResponse = {
        success: false,
        message: 'Failed to fetch security settings',
        error: error instanceof Error ? error.message : 'Unknown error'
      };
      res.status(500).json(response);
    }
  }

  /**
   * Update security settings
   */
  static async updateSecuritySettings(req: Request, res: Response): Promise<void> {
    try {
      const settingsData = req.body;
      
      const settings = await SettingsService.updateSecuritySettings(settingsData);
      
      const response: ApiResponse = {
        success: true,
        message: 'Security settings updated successfully',
        data: settings
      };

      res.status(200).json(response);
    } catch (error) {
      console.error('Error updating security settings:', error);
      const response: ApiResponse = {
        success: false,
        message: 'Failed to update security settings',
        error: error instanceof Error ? error.message : 'Unknown error'
      };
      res.status(500).json(response);
    }
  }

  /**
   * Get system configuration settings
   */
  static async getSystemConfigSettings(req: Request, res: Response): Promise<void> {
    try {
      const settings = await SettingsService.getSystemConfigSettings();
      
      const response: ApiResponse = {
        success: true,
        message: 'System configuration settings retrieved successfully',
        data: settings
      };

      res.status(200).json(response);
    } catch (error) {
      console.error('Error fetching system config settings:', error);
      const response: ApiResponse = {
        success: false,
        message: 'Failed to fetch system configuration settings',
        error: error instanceof Error ? error.message : 'Unknown error'
      };
      res.status(500).json(response);
    }
  }

  /**
   * Update system configuration settings
   */
  static async updateSystemConfigSettings(req: Request, res: Response): Promise<void> {
    try {
      const settingsData = req.body;
      
      const settings = await SettingsService.updateSystemConfigSettings(settingsData);
      
      const response: ApiResponse = {
        success: true,
        message: 'System configuration settings updated successfully',
        data: settings
      };

      res.status(200).json(response);
    } catch (error) {
      console.error('Error updating system config settings:', error);
      const response: ApiResponse = {
        success: false,
        message: 'Failed to update system configuration settings',
        error: error instanceof Error ? error.message : 'Unknown error'
      };
      res.status(500).json(response);
    }
  }

  /**
   * Reset settings to default
   */
  static async resetSettingsToDefault(req: Request, res: Response): Promise<void> {
    try {
      const { category } = req.body;
      
      const settings = await SettingsService.resetSettingsToDefault(category);
      
      const response: ApiResponse = {
        success: true,
        message: 'Settings reset to default successfully',
        data: settings
      };

      res.status(200).json(response);
    } catch (error) {
      console.error('Error resetting settings to default:', error);
      const response: ApiResponse = {
        success: false,
        message: 'Failed to reset settings to default',
        error: error instanceof Error ? error.message : 'Unknown error'
      };
      res.status(500).json(response);
    }
  }

  /**
   * Export settings
   */
  static async exportSettings(req: Request, res: Response): Promise<void> {
    try {
      const { format = 'json' } = req.query;
      
      const exportData = await SettingsService.exportSettings(format as string);
      
      // Set appropriate headers based on format
      const contentType = {
        json: 'application/json',
        yaml: 'application/x-yaml',
        csv: 'text/csv'
      }[format as string] || 'application/json';

      const extension = format || 'json';
      const filename = `settings-${Date.now()}.${extension}`;

      res.setHeader('Content-Type', contentType);
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      
      res.status(200).send(exportData);
    } catch (error) {
      console.error('Error exporting settings:', error);
      const response: ApiResponse = {
        success: false,
        message: 'Failed to export settings',
        error: error instanceof Error ? error.message : 'Unknown error'
      };
      res.status(500).json(response);
    }
  }

  /**
   * Import settings
   */
  static async importSettings(req: Request, res: Response): Promise<void> {
    try {
      const settingsData = req.body;
      
      const result = await SettingsService.importSettings(settingsData);
      
      const response: ApiResponse = {
        success: true,
        message: 'Settings imported successfully',
        data: result
      };

      res.status(200).json(response);
    } catch (error) {
      console.error('Error importing settings:', error);
      const response: ApiResponse = {
        success: false,
        message: 'Failed to import settings',
        error: error instanceof Error ? error.message : 'Unknown error'
      };
      res.status(500).json(response);
    }
  }

  /**
   * Get settings history
   */
  static async getSettingsHistory(req: Request, res: Response): Promise<void> {
    try {
      const { category, page = 1, limit = 10 } = req.query;
      
      const history = await SettingsService.getSettingsHistory(
        category as string,
        Number(page),
        Number(limit)
      );
      
      const response: ApiResponse = {
        success: true,
        message: 'Settings history retrieved successfully',
        data: history
      };

      res.status(200).json(response);
    } catch (error) {
      console.error('Error fetching settings history:', error);
      const response: ApiResponse = {
        success: false,
        message: 'Failed to fetch settings history',
        error: error instanceof Error ? error.message : 'Unknown error'
      };
      res.status(500).json(response);
    }
  }
}
