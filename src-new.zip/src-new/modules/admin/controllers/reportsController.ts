import { Request, Response } from 'express';
import { ReportsService } from '../services/reportsService';
import { ApiResponse } from '../types';

export class ReportsController {
  /**
   * Get general reports data
   */
  static async getReports(req: Request, res: Response): Promise<void> {
    try {
      const { period, type } = req.query;
      
      let data: any = {};
      
      if (type === 'available') {
        // Return available report types
        data = {
          reports: [
            'Leave Trends',
            'Department Statistics', 
            'Leave Balance',
            'Employee Summary',
            'Utilization Report',
            'Monthly Report'
          ]
        };
      } else {
        // Return dashboard report data
        const reportStats = await ReportsService.getReportDashboard();
        data = {
          totalReports: reportStats.totalReports || 0,
          activeUsers: reportStats.activeUsers || 0,
          dataPoints: reportStats.dataPoints || 0,
          exportSuccess: reportStats.exportSuccess || 0
        };
      }
      
      const response: ApiResponse = {
        success: true,
        message: 'Reports data retrieved successfully',
        data
      };

      res.status(200).json(response);
    } catch (error) {
      console.error('Error fetching reports data:', error);
      const response: ApiResponse = {
        success: false,
        message: 'Failed to fetch reports data',
        error: error instanceof Error ? error.message : 'Unknown error'
      };
      res.status(500).json(response);
    }
  }

  /**
   * Get leave trends report
   */
  static async getLeaveTrends(req: Request, res: Response): Promise<void> {
    try {
      const { startDate, endDate, department, leaveType } = req.query;
      
      const filters = {
        startDate: startDate as string,
        endDate: endDate as string,
        department: department as string,
        leaveType: leaveType as string
      };

      const trends = await ReportsService.getLeaveTrends(filters);
      
      const response: ApiResponse = {
        success: true,
        message: 'Leave trends retrieved successfully',
        data: trends
      };

      res.status(200).json(response);
    } catch (error) {
      console.error('Error fetching leave trends:', error);
      const response: ApiResponse = {
        success: false,
        message: 'Failed to fetch leave trends',
        error: error instanceof Error ? error.message : 'Unknown error'
      };
      res.status(500).json(response);
    }
  }

  /**
   * Get department statistics report
   */
  static async getDepartmentStats(req: Request, res: Response): Promise<void> {
    try {
      const { startDate, endDate } = req.query;
      
      const filters = {
        startDate: startDate as string,
        endDate: endDate as string
      };

      const stats = await ReportsService.getDepartmentStats(filters);
      
      const response: ApiResponse = {
        success: true,
        message: 'Department statistics retrieved successfully',
        data: stats
      };

      res.status(200).json(response);
    } catch (error) {
      console.error('Error fetching department stats:', error);
      const response: ApiResponse = {
        success: false,
        message: 'Failed to fetch department statistics',
        error: error instanceof Error ? error.message : 'Unknown error'
      };
      res.status(500).json(response);
    }
  }

  /**
   * Get leave balance report
   */
  static async getLeaveBalanceReport(req: Request, res: Response): Promise<void> {
    try {
      const { department, year } = req.query;
      
      const filters = {
        department: department as string,
        year: year ? Number(year) : new Date().getFullYear()
      };

      const report = await ReportsService.getLeaveBalanceReport(filters);
      
      const response: ApiResponse = {
        success: true,
        message: 'Leave balance report retrieved successfully',
        data: report
      };

      res.status(200).json(response);
    } catch (error) {
      console.error('Error fetching leave balance report:', error);
      const response: ApiResponse = {
        success: false,
        message: 'Failed to fetch leave balance report',
        error: error instanceof Error ? error.message : 'Unknown error'
      };
      res.status(500).json(response);
    }
  }

  /**
   * Get employee leave summary
   */
  static async getEmployeeLeaveSummary(req: Request, res: Response): Promise<void> {
    try {
      const { employeeId, year } = req.query;
      
      const filters = {
        employeeId: employeeId as string,
        year: year ? Number(year) : new Date().getFullYear()
      };

      const summary = await ReportsService.getEmployeeLeaveSummary(filters);
      
      const response: ApiResponse = {
        success: true,
        message: 'Employee leave summary retrieved successfully',
        data: summary
      };

      res.status(200).json(response);
    } catch (error) {
      console.error('Error fetching employee leave summary:', error);
      const response: ApiResponse = {
        success: false,
        message: 'Failed to fetch employee leave summary',
        error: error instanceof Error ? error.message : 'Unknown error'
      };
      res.status(500).json(response);
    }
  }

  /**
   * Get leave utilization report
   */
  static async getLeaveUtilizationReport(req: Request, res: Response): Promise<void> {
    try {
      const { startDate, endDate, department, leaveType } = req.query;
      
      const filters = {
        startDate: startDate as string,
        endDate: endDate as string,
        department: department as string,
        leaveType: leaveType as string
      };

      const report = await ReportsService.getLeaveUtilizationReport(filters);
      
      const response: ApiResponse = {
        success: true,
        message: 'Leave utilization report retrieved successfully',
        data: report
      };

      res.status(200).json(response);
    } catch (error) {
      console.error('Error fetching leave utilization report:', error);
      const response: ApiResponse = {
        success: false,
        message: 'Failed to fetch leave utilization report',
        error: error instanceof Error ? error.message : 'Unknown error'
      };
      res.status(500).json(response);
    }
  }

  /**
   * Get monthly leave report
   */
  static async getMonthlyLeaveReport(req: Request, res: Response): Promise<void> {
    try {
      const { year, month, department } = req.query;
      
      const filters = {
        year: year ? Number(year) : new Date().getFullYear(),
        month: month ? Number(month) : new Date().getMonth() + 1,
        department: department as string
      };

      const report = await ReportsService.getMonthlyLeaveReport(filters);
      
      const response: ApiResponse = {
        success: true,
        message: 'Monthly leave report retrieved successfully',
        data: report
      };

      res.status(200).json(response);
    } catch (error) {
      console.error('Error fetching monthly leave report:', error);
      const response: ApiResponse = {
        success: false,
        message: 'Failed to fetch monthly leave report',
        error: error instanceof Error ? error.message : 'Unknown error'
      };
      res.status(500).json(response);
    }
  }

  /**
   * Export report data
   */
  static async exportReport(req: Request, res: Response): Promise<void> {
    try {
      const { reportType, format, startDate, endDate, department } = req.query;
      
      const filters = {
        reportType: reportType as string,
        format: format as 'pdf' | 'excel' | 'csv',
        startDate: startDate as string,
        endDate: endDate as string,
        department: department as string
      };

      const exportData = await ReportsService.exportReport(filters);
      
      // Set appropriate headers based on format
      const contentType = {
        pdf: 'application/pdf',
        excel: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        csv: 'text/csv'
      }[filters.format] || 'application/octet-stream';

      const extension = filters.format || 'csv';
      const filename = `leave-report-${Date.now()}.${extension}`;

      res.setHeader('Content-Type', contentType);
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      
      res.status(200).send(exportData);
    } catch (error) {
      console.error('Error exporting report:', error);
      const response: ApiResponse = {
        success: false,
        message: 'Failed to export report',
        error: error instanceof Error ? error.message : 'Unknown error'
      };
      res.status(500).json(response);
    }
  }

  /**
   * Get report dashboard data
   */
  static async getReportDashboard(req: Request, res: Response): Promise<void> {
    try {
      const { year } = req.query;
      
      const yearFilter = year ? Number(year) : new Date().getFullYear();
      const dashboard = await ReportsService.getReportDashboard(yearFilter);
      
      const response: ApiResponse = {
        success: true,
        message: 'Report dashboard data retrieved successfully',
        data: dashboard
      };

      res.status(200).json(response);
    } catch (error) {
      console.error('Error fetching report dashboard:', error);
      const response: ApiResponse = {
        success: false,
        message: 'Failed to fetch report dashboard data',
        error: error instanceof Error ? error.message : 'Unknown error'
      };
      res.status(500).json(response);
    }
  }

  /**
   * Get available report types
   */
  static async getAvailableReportTypes(req: Request, res: Response): Promise<void> {
    try {
      const reportTypes = await ReportsService.getAvailableReportTypes();
      
      const response: ApiResponse = {
        success: true,
        message: 'Available report types retrieved successfully',
        data: reportTypes
      };

      res.status(200).json(response);
    } catch (error) {
      console.error('Error fetching available report types:', error);
      const response: ApiResponse = {
        success: false,
        message: 'Failed to fetch available report types',
        error: error instanceof Error ? error.message : 'Unknown error'
      };
      res.status(500).json(response);
    }
  }
}
