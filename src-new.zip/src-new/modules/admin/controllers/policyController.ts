import { Request, Response } from 'express';
import { PolicyService } from '../services/policyService';
import { ApiResponse } from '../../../types';

export class PolicyController {
  /**
   * Get all policies for admin
   */
  static async getPolicies(req: Request, res: Response): Promise<void> {
    try {
      const { status, limit = 50, page = 1 } = req.query;
      
      const policies = await PolicyService.getPolicies({
        status: status as string,
        limit: parseInt(limit as string),
        page: parseInt(page as string)
      });

      const response: ApiResponse = {
        success: true,
        message: 'Policies retrieved successfully',
        data: policies
      };

      res.status(200).json(response);
    } catch (error) {
      console.error('Error in getPolicies:', error);
      
      const response: ApiResponse = {
        success: false,
        message: 'Failed to retrieve policies',
        error: error instanceof Error ? error.message : 'Unknown error'
      };

      res.status(500).json(response);
    }
  }

  /**
   * Create a new policy
   */
  static async createPolicy(req: Request, res: Response): Promise<void> {
    try {
      const policyData = req.body;
      
      const policy = await PolicyService.createPolicy(policyData);

      const response: ApiResponse = {
        success: true,
        message: 'Policy created successfully',
        data: policy
      };

      res.status(201).json(response);
    } catch (error) {
      console.error('Error in createPolicy:', error);
      
      const response: ApiResponse = {
        success: false,
        message: 'Failed to create policy',
        error: error instanceof Error ? error.message : 'Unknown error'
      };

      res.status(500).json(response);
    }
  }

  /**
   * Get policy by ID
   */
  static async getPolicyById(req: Request, res: Response): Promise<void> {
    try {
      const { id } = req.params;
      
      const policy = await PolicyService.getPolicyById(id);

      if (!policy) {
        const response: ApiResponse = {
          success: false,
          message: 'Policy not found',
          error: 'Policy with the given ID does not exist'
        };
        res.status(404).json(response);
        return;
      }

      const response: ApiResponse = {
        success: true,
        message: 'Policy retrieved successfully',
        data: policy
      };

      res.status(200).json(response);
    } catch (error) {
      console.error('Error in getPolicyById:', error);
      
      const response: ApiResponse = {
        success: false,
        message: 'Failed to retrieve policy',
        error: error instanceof Error ? error.message : 'Unknown error'
      };

      res.status(500).json(response);
    }
  }

  /**
   * Update policy
   */
  static async updatePolicy(req: Request, res: Response): Promise<void> {
    try {
      const { id } = req.params;
      const updateData = req.body;
      
      const policy = await PolicyService.updatePolicy(id, updateData);

      if (!policy) {
        const response: ApiResponse = {
          success: false,
          message: 'Policy not found',
          error: 'Policy with the given ID does not exist'
        };
        res.status(404).json(response);
        return;
      }

      const response: ApiResponse = {
        success: true,
        message: 'Policy updated successfully',
        data: policy
      };

      res.status(200).json(response);
    } catch (error) {
      console.error('Error in updatePolicy:', error);
      
      const response: ApiResponse = {
        success: false,
        message: 'Failed to update policy',
        error: error instanceof Error ? error.message : 'Unknown error'
      };

      res.status(500).json(response);
    }
  }

  /**
   * Delete policy
   */
  static async deletePolicy(req: Request, res: Response): Promise<void> {
    try {
      const { id } = req.params;
      
      const success = await PolicyService.deletePolicy(id);

      if (!success) {
        const response: ApiResponse = {
          success: false,
          message: 'Policy not found',
          error: 'Policy with the given ID does not exist'
        };
        res.status(404).json(response);
        return;
      }

      const response: ApiResponse = {
        success: true,
        message: 'Policy deleted successfully'
      };

      res.status(200).json(response);
    } catch (error) {
      console.error('Error in deletePolicy:', error);
      
      const response: ApiResponse = {
        success: false,
        message: 'Failed to delete policy',
        error: error instanceof Error ? error.message : 'Unknown error'
      };

      res.status(500).json(response);
    }
  }
}
