import { Request, Response } from 'express';
import { LeavePolicyService } from '../services/leavePolicyService';
import { ApiResponse } from '../types';

export class LeavePolicyController {
  /**
   * Get all leave policies with filtering and pagination
   */
  static async getLeavePolicies(req: Request, res: Response): Promise<void> {
    try {
      const { page = 1, limit = 10, search = '', status = 'all' } = req.query;
      
      const filters = {
        page: Number(page),
        limit: Number(limit),
        search: String(search),
        status: String(status) as 'all' | 'active' | 'inactive'
      };

      const result = await LeavePolicyService.getLeavePolicies(filters);
      
      const response: ApiResponse = {
        success: true,
        message: 'Leave policies retrieved successfully',
        data: result
      };

      res.status(200).json(response);
    } catch (error) {
      console.error('Error fetching leave policies:', error);
      const response: ApiResponse = {
        success: false,
        message: 'Failed to fetch leave policies',
        error: error instanceof Error ? error.message : 'Unknown error'
      };
      res.status(500).json(response);
    }
  }

  /**
   * Get leave policy by ID
   */
  static async getLeavePolicyById(req: Request, res: Response): Promise<void> {
    try {
      const { id } = req.params;
      
      const policy = await LeavePolicyService.getLeavePolicyById(id);
      
      if (!policy) {
        const response: ApiResponse = {
          success: false,
          message: 'Leave policy not found'
        };
        res.status(404).json(response);
        return;
      }

      const response: ApiResponse = {
        success: true,
        message: 'Leave policy retrieved successfully',
        data: policy
      };

      res.status(200).json(response);
    } catch (error) {
      console.error('Error fetching leave policy:', error);
      const response: ApiResponse = {
        success: false,
        message: 'Failed to fetch leave policy',
        error: error instanceof Error ? error.message : 'Unknown error'
      };
      res.status(500).json(response);
    }
  }

  /**
   * Create new leave policy
   */
  static async createLeavePolicy(req: Request, res: Response): Promise<void> {
    try {
      const policyData = req.body;
      
      const policy = await LeavePolicyService.createLeavePolicy(policyData);
      
      const response: ApiResponse = {
        success: true,
        message: 'Leave policy created successfully',
        data: policy
      };

      res.status(201).json(response);
    } catch (error) {
      console.error('Error creating leave policy:', error);
      const response: ApiResponse = {
        success: false,
        message: 'Failed to create leave policy',
        error: error instanceof Error ? error.message : 'Unknown error'
      };
      res.status(500).json(response);
    }
  }

  /**
   * Update leave policy
   */
  static async updateLeavePolicy(req: Request, res: Response): Promise<void> {
    try {
      const { id } = req.params;
      const updateData = req.body;
      
      const policy = await LeavePolicyService.updateLeavePolicy(id, updateData);
      
      if (!policy) {
        const response: ApiResponse = {
          success: false,
          message: 'Leave policy not found'
        };
        res.status(404).json(response);
        return;
      }

      const response: ApiResponse = {
        success: true,
        message: 'Leave policy updated successfully',
        data: policy
      };

      res.status(200).json(response);
    } catch (error) {
      console.error('Error updating leave policy:', error);
      const response: ApiResponse = {
        success: false,
        message: 'Failed to update leave policy',
        error: error instanceof Error ? error.message : 'Unknown error'
      };
      res.status(500).json(response);
    }
  }

  /**
   * Delete leave policy
   */
  static async deleteLeavePolicy(req: Request, res: Response): Promise<void> {
    try {
      const { id } = req.params;
      
      const deleted = await LeavePolicyService.deleteLeavePolicy(id);
      
      if (!deleted) {
        const response: ApiResponse = {
          success: false,
          message: 'Leave policy not found'
        };
        res.status(404).json(response);
        return;
      }

      const response: ApiResponse = {
        success: true,
        message: 'Leave policy deleted successfully'
      };

      res.status(200).json(response);
    } catch (error) {
      console.error('Error deleting leave policy:', error);
      const response: ApiResponse = {
        success: false,
        message: 'Failed to delete leave policy',
        error: error instanceof Error ? error.message : 'Unknown error'
      };
      res.status(500).json(response);
    }
  }

  /**
   * Toggle leave policy status (active/inactive)
   */
  static async toggleLeavePolicyStatus(req: Request, res: Response): Promise<void> {
    try {
      const { id } = req.params;
      const { isActive } = req.body;
      
      const policy = await LeavePolicyService.toggleLeavePolicyStatus(id, isActive);
      
      if (!policy) {
        const response: ApiResponse = {
          success: false,
          message: 'Leave policy not found'
        };
        res.status(404).json(response);
        return;
      }

      const response: ApiResponse = {
        success: true,
        message: `Leave policy ${isActive ? 'activated' : 'deactivated'} successfully`,
        data: policy
      };

      res.status(200).json(response);
    } catch (error) {
      console.error('Error toggling leave policy status:', error);
      const response: ApiResponse = {
        success: false,
        message: 'Failed to toggle leave policy status',
        error: error instanceof Error ? error.message : 'Unknown error'
      };
      res.status(500).json(response);
    }
  }

  /**
   * Get leave policy statistics
   */
  static async getLeavePolicyStats(req: Request, res: Response): Promise<void> {
    try {
      const stats = await LeavePolicyService.getLeavePolicyStats();
      
      const response: ApiResponse = {
        success: true,
        message: 'Leave policy statistics retrieved successfully',
        data: stats
      };

      res.status(200).json(response);
    } catch (error) {
      console.error('Error fetching leave policy stats:', error);
      const response: ApiResponse = {
        success: false,
        message: 'Failed to fetch leave policy statistics',
        error: error instanceof Error ? error.message : 'Unknown error'
      };
      res.status(500).json(response);
    }
  }

  /**
   * Get leave policy types
   */
  static async getLeavePolicyTypes(req: Request, res: Response): Promise<void> {
    try {
      const types = await LeavePolicyService.getLeavePolicyTypes();
      
      const response: ApiResponse = {
        success: true,
        message: 'Leave policy types retrieved successfully',
        data: types
      };

      res.status(200).json(response);
    } catch (error) {
      console.error('Error fetching leave policy types:', error);
      const response: ApiResponse = {
        success: false,
        message: 'Failed to fetch leave policy types',
        error: error instanceof Error ? error.message : 'Unknown error'
      };
      res.status(500).json(response);
    }
  }

  /**
   * Bulk update leave policies
   */
  static async bulkUpdateLeavePolicies(req: Request, res: Response): Promise<void> {
    try {
      const { policyIds, updates } = req.body;
      
      const result = await LeavePolicyService.bulkUpdateLeavePolicies(policyIds, updates);
      
      const response: ApiResponse = {
        success: true,
        message: 'Leave policies updated successfully',
        data: result
      };

      res.status(200).json(response);
    } catch (error) {
      console.error('Error bulk updating leave policies:', error);
      const response: ApiResponse = {
        success: false,
        message: 'Failed to bulk update leave policies',
        error: error instanceof Error ? error.message : 'Unknown error'
      };
      res.status(500).json(response);
    }
  }
}
