import { Request, Response } from 'express';
import { AuditLogService } from '../services/auditLogService';
import { ApiResponse } from '../types';

export class AuditLogController {
  /**
   * Get audit logs with filtering and pagination
   */
  static async getAuditLogs(req: Request, res: Response): Promise<void> {
    try {
      const {
        page = 1,
        limit = 10,
        search = '',
        action = '',
        userId = '',
        startDate,
        endDate,
        sortBy = 'timestamp',
        sortOrder = 'desc'
      } = req.query;
      
      const filters = {
        page: Number(page),
        limit: Number(limit),
        search: String(search),
        action: String(action),
        userId: String(userId),
        startDate: startDate as string,
        endDate: endDate as string,
        sortBy: String(sortBy),
        sortOrder: String(sortOrder) as 'asc' | 'desc'
      };

      const result = await AuditLogService.getAuditLogs(filters);
      
      const response: ApiResponse = {
        success: true,
        message: 'Audit logs retrieved successfully',
        data: result
      };

      res.status(200).json(response);
    } catch (error) {
      console.error('Error fetching audit logs:', error);
      const response: ApiResponse = {
        success: false,
        message: 'Failed to fetch audit logs',
        error: error instanceof Error ? error.message : 'Unknown error'
      };
      res.status(500).json(response);
    }
  }

  /**
   * Get audit log by ID
   */
  static async getAuditLogById(req: Request, res: Response): Promise<void> {
    try {
      const { id } = req.params;
      
      const auditLog = await AuditLogService.getAuditLogById(id);
      
      if (!auditLog) {
        const response: ApiResponse = {
          success: false,
          message: 'Audit log not found'
        };
        res.status(404).json(response);
        return;
      }

      const response: ApiResponse = {
        success: true,
        message: 'Audit log retrieved successfully',
        data: auditLog
      };

      res.status(200).json(response);
    } catch (error) {
      console.error('Error fetching audit log:', error);
      const response: ApiResponse = {
        success: false,
        message: 'Failed to fetch audit log',
        error: error instanceof Error ? error.message : 'Unknown error'
      };
      res.status(500).json(response);
    }
  }

  /**
   * Get audit log statistics
   */
  static async getAuditLogStats(req: Request, res: Response): Promise<void> {
    try {
      const { startDate, endDate } = req.query;
      
      const filters = {
        startDate: startDate as string,
        endDate: endDate as string
      };

      const stats = await AuditLogService.getAuditLogStats(filters);
      
      const response: ApiResponse = {
        success: true,
        message: 'Audit log statistics retrieved successfully',
        data: stats
      };

      res.status(200).json(response);
    } catch (error) {
      console.error('Error fetching audit log stats:', error);
      const response: ApiResponse = {
        success: false,
        message: 'Failed to fetch audit log statistics',
        error: error instanceof Error ? error.message : 'Unknown error'
      };
      res.status(500).json(response);
    }
  }

  /**
   * Get audit log actions
   */
  static async getAuditLogActions(req: Request, res: Response): Promise<void> {
    try {
      const actions = await AuditLogService.getAuditLogActions();
      
      const response: ApiResponse = {
        success: true,
        message: 'Audit log actions retrieved successfully',
        data: actions
      };

      res.status(200).json(response);
    } catch (error) {
      console.error('Error fetching audit log actions:', error);
      const response: ApiResponse = {
        success: false,
        message: 'Failed to fetch audit log actions',
        error: error instanceof Error ? error.message : 'Unknown error'
      };
      res.status(500).json(response);
    }
  }

  /**
   * Get user activity summary
   */
  static async getUserActivitySummary(req: Request, res: Response): Promise<void> {
    try {
      const { userId, days = 30 } = req.query;
      
      const summary = await AuditLogService.getUserActivitySummary(
        userId as string,
        Number(days)
      );
      
      const response: ApiResponse = {
        success: true,
        message: 'User activity summary retrieved successfully',
        data: summary
      };

      res.status(200).json(response);
    } catch (error) {
      console.error('Error fetching user activity summary:', error);
      const response: ApiResponse = {
        success: false,
        message: 'Failed to fetch user activity summary',
        error: error instanceof Error ? error.message : 'Unknown error'
      };
      res.status(500).json(response);
    }
  }

  /**
   * Get system activity summary
   */
  static async getSystemActivitySummary(req: Request, res: Response): Promise<void> {
    try {
      const { days = 30 } = req.query;
      
      const summary = await AuditLogService.getSystemActivitySummary(Number(days));
      
      const response: ApiResponse = {
        success: true,
        message: 'System activity summary retrieved successfully',
        data: summary
      };

      res.status(200).json(response);
    } catch (error) {
      console.error('Error fetching system activity summary:', error);
      const response: ApiResponse = {
        success: false,
        message: 'Failed to fetch system activity summary',
        error: error instanceof Error ? error.message : 'Unknown error'
      };
      res.status(500).json(response);
    }
  }

  /**
   * Export audit logs
   */
  static async exportAuditLogs(req: Request, res: Response): Promise<void> {
    try {
      const {
        format = 'csv',
        startDate,
        endDate,
        action,
        userId
      } = req.query;
      
      const filters = {
        format: format as 'csv' | 'excel' | 'pdf',
        startDate: startDate as string,
        endDate: endDate as string,
        action: action as string,
        userId: userId as string
      };

      const exportData = await AuditLogService.exportAuditLogs(filters);
      
      // Set appropriate headers based on format
      const contentType = {
        pdf: 'application/pdf',
        excel: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        csv: 'text/csv'
      }[filters.format] || 'text/csv';

      const extension = filters.format || 'csv';
      const filename = `audit-logs-${Date.now()}.${extension}`;

      res.setHeader('Content-Type', contentType);
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      
      res.status(200).send(exportData);
    } catch (error) {
      console.error('Error exporting audit logs:', error);
      const response: ApiResponse = {
        success: false,
        message: 'Failed to export audit logs',
        error: error instanceof Error ? error.message : 'Unknown error'
      };
      res.status(500).json(response);
    }
  }

  /**
   * Get audit log dashboard data
   */
  static async getAuditLogDashboard(req: Request, res: Response): Promise<void> {
    try {
      const { days = 7 } = req.query;
      
      const dashboard = await AuditLogService.getAuditLogDashboard(Number(days));
      
      const response: ApiResponse = {
        success: true,
        message: 'Audit log dashboard data retrieved successfully',
        data: dashboard
      };

      res.status(200).json(response);
    } catch (error) {
      console.error('Error fetching audit log dashboard:', error);
      const response: ApiResponse = {
        success: false,
        message: 'Failed to fetch audit log dashboard data',
        error: error instanceof Error ? error.message : 'Unknown error'
      };
      res.status(500).json(response);
    }
  }

  /**
   * Create audit log entry (for internal use)
   */
  static async createAuditLog(req: Request, res: Response): Promise<void> {
    try {
      const auditLogData = req.body;
      
      const auditLog = await AuditLogService.createAuditLog(auditLogData);
      
      const response: ApiResponse = {
        success: true,
        message: 'Audit log created successfully',
        data: auditLog
      };

      res.status(201).json(response);
    } catch (error) {
      console.error('Error creating audit log:', error);
      const response: ApiResponse = {
        success: false,
        message: 'Failed to create audit log',
        error: error instanceof Error ? error.message : 'Unknown error'
      };
      res.status(500).json(response);
    }
  }
}
