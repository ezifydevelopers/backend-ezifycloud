import { Request, Response } from 'express';
import { LeavePolicyService } from '../../admin/services/leavePolicyService';
import { LeavePolicyFilters } from '../../admin/types';

export class LeavePolicyController {
  /**
   * Get leave policies (read-only access for employees)
   */
  static async getLeavePolicies(req: Request, res: Response): Promise<void> {
    try {
      const filters: LeavePolicyFilters = {
        search: req.query.search as string || '',
        leaveType: req.query.leaveType as string || '',
        status: (req.query.status as 'all' | 'active' | 'inactive') || 'all',
        page: parseInt(req.query.page as string) || 1,
        limit: parseInt(req.query.limit as string) || 10,
        sortBy: req.query.sortBy as string || 'createdAt',
        sortOrder: req.query.sortOrder as 'asc' | 'desc' || 'desc'
      };

      console.log('🔍 Employee LeavePolicyController: getLeavePolicies called with filters:', filters);

      const result = await LeavePolicyService.getLeavePolicies(filters);

      res.status(200).json({
        success: true,
        message: 'Leave policies retrieved successfully',
        data: result.policies,
        pagination: {
          page: result.pagination.page,
          limit: result.pagination.limit,
          total: result.pagination.totalItems,
          totalPages: result.pagination.totalPages
        },
        filters: result.filters
      });
    } catch (error) {
      console.error('Error fetching leave policies:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to fetch leave policies',
        error: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  }

  /**
   * Get leave policy by ID (read-only access for employees)
   */
  static async getLeavePolicyById(req: Request, res: Response): Promise<void> {
    try {
      const { id } = req.params;

      console.log('🔍 Employee LeavePolicyController: getLeavePolicyById called with id:', id);

      const policy = await LeavePolicyService.getLeavePolicyById(id);

      if (!policy) {
        res.status(404).json({
          success: false,
          message: 'Leave policy not found'
        });
        return;
      }

      res.status(200).json({
        success: true,
        message: 'Leave policy retrieved successfully',
        data: policy
      });
    } catch (error) {
      console.error('Error fetching leave policy:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to fetch leave policy',
        error: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  }

  /**
   * Get leave policy statistics (read-only access for employees)
   */
  static async getLeavePolicyStats(req: Request, res: Response): Promise<void> {
    try {
      console.log('🔍 Employee LeavePolicyController: getLeavePolicyStats called');
      console.log('🔍 Request query:', req.query);
      console.log('🔍 Request headers:', req.headers);

      const stats = await LeavePolicyService.getLeavePolicyStats();

      // Map backend response to frontend expected format
      const mappedStats = {
        totalPolicies: stats.total,
        activePolicies: stats.active,
        inactivePolicies: stats.inactive,
        byLeaveType: stats.byLeaveType
      };

      res.status(200).json({
        success: true,
        message: 'Leave policy statistics retrieved successfully',
        data: mappedStats
      });
    } catch (error) {
      console.error('Error fetching leave policy stats:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to fetch leave policy statistics',
        error: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  }

  /**
   * Get leave policy types (read-only access for employees)
   */
  static async getLeavePolicyTypes(req: Request, res: Response): Promise<void> {
    try {
      console.log('🔍 Employee LeavePolicyController: getLeavePolicyTypes called');

      const types = await LeavePolicyService.getLeavePolicyTypes();

      res.status(200).json({
        success: true,
        message: 'Leave policy types retrieved successfully',
        data: types
      });
    } catch (error) {
      console.error('Error fetching leave policy types:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to fetch leave policy types',
        error: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  }
}
