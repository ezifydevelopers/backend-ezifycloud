import { Request, Response } from 'express';
import { ApiResponse, CalendarFilters } from '../types';
import { CalendarService } from '../services/calendarService';

export class CalendarController {
  /**
   * Get calendar events for employee
   */
  static async getCalendarEvents(req: Request, res: Response): Promise<void> {
    try {
      const employeeId = (req as any).user?.id;
      const filters: CalendarFilters = {
        startDate: req.query.startDate as string,
        endDate: req.query.endDate as string,
        eventType: req.query.eventType as 'leave' | 'holiday' | 'meeting' | 'event' | 'all',
        leaveType: req.query.leaveType as string,
        status: req.query.status as string
      };

      if (!employeeId) {
        const response: ApiResponse = {
          success: false,
          message: 'Employee ID is required',
          error: 'Missing employee information'
        };
        res.status(400).json(response);
        return;
      }

      // Validate required parameters
      if (!filters.startDate || !filters.endDate) {
        const response: ApiResponse = {
          success: false,
          message: 'Start date and end date are required',
          error: 'Missing required parameters'
        };
        res.status(400).json(response);
        return;
      }

      const calendarData = await CalendarService.getCalendarEvents(employeeId, filters);

      const response: ApiResponse = {
        success: true,
        message: 'Calendar events retrieved successfully',
        data: calendarData
      };

      res.status(200).json(response);
    } catch (error) {
      console.error('Error in getCalendarEvents:', error);
      
      const response: ApiResponse = {
        success: false,
        message: 'Failed to retrieve calendar events',
        error: error instanceof Error ? error.message : 'Unknown error'
      };

      res.status(500).json(response);
    }
  }

  /**
   * Get calendar events for current month
   */
  static async getCurrentMonthEvents(req: Request, res: Response): Promise<void> {
    try {
      const employeeId = (req as any).user?.id;
      
      if (!employeeId) {
        const response: ApiResponse = {
          success: false,
          message: 'Employee ID is required',
          error: 'Missing employee information'
        };
        res.status(400).json(response);
        return;
      }

      // Get current month date range
      const now = new Date();
      const startDate = new Date(now.getFullYear(), now.getMonth(), 1);
      const endDate = new Date(now.getFullYear(), now.getMonth() + 1, 0);

      const filters: CalendarFilters = {
        startDate: startDate.toISOString(),
        endDate: endDate.toISOString(),
        eventType: req.query.eventType as 'leave' | 'holiday' | 'meeting' | 'event' | 'all' || 'all',
        leaveType: req.query.leaveType as string,
        status: req.query.status as string
      };

      const calendarData = await CalendarService.getCalendarEvents(employeeId, filters);

      const response: ApiResponse = {
        success: true,
        message: 'Current month calendar events retrieved successfully',
        data: calendarData
      };

      res.status(200).json(response);
    } catch (error) {
      console.error('Error in getCurrentMonthEvents:', error);
      
      const response: ApiResponse = {
        success: false,
        message: 'Failed to retrieve current month calendar events',
        error: error instanceof Error ? error.message : 'Unknown error'
      };

      res.status(500).json(response);
    }
  }
}
