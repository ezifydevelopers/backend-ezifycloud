import { Request, Response } from 'express';
import { PolicyService } from '../services/policyService';
import { ApiResponse } from '../../../types';

export class PolicyController {
  /**
   * Get all active policies for employees
   */
  static async getPolicies(req: Request, res: Response): Promise<void> {
    try {
      const { status = 'active', limit = 50 } = req.query;
      
      const policies = await PolicyService.getPolicies({
        status: status as string,
        limit: parseInt(limit as string)
      });

      const response: ApiResponse = {
        success: true,
        message: 'Policies retrieved successfully',
        data: policies
      };

      res.status(200).json(response);
    } catch (error) {
      console.error('Error in getPolicies:', error);
      
      const response: ApiResponse = {
        success: false,
        message: 'Failed to retrieve policies',
        error: error instanceof Error ? error.message : 'Unknown error'
      };

      res.status(500).json(response);
    }
  }

  /**
   * Get policy by ID
   */
  static async getPolicyById(req: Request, res: Response): Promise<void> {
    try {
      const { id } = req.params;
      
      const policy = await PolicyService.getPolicyById(id);

      if (!policy) {
        const response: ApiResponse = {
          success: false,
          message: 'Policy not found',
          error: 'Policy with the given ID does not exist'
        };
        res.status(404).json(response);
        return;
      }

      const response: ApiResponse = {
        success: true,
        message: 'Policy retrieved successfully',
        data: policy
      };

      res.status(200).json(response);
    } catch (error) {
      console.error('Error in getPolicyById:', error);
      
      const response: ApiResponse = {
        success: false,
        message: 'Failed to retrieve policy',
        error: error instanceof Error ? error.message : 'Unknown error'
      };

      res.status(500).json(response);
    }
  }
}
