import { 
  CalendarEvent, 
  CalendarFilters, 
  CalendarResponse, 
  MonthStats,
  Holiday 
} from '../types';
import prisma from '../../../lib/prisma';

export class CalendarService {
  /**
   * Get calendar events for a specific date range
   */
  static async getCalendarEvents(employeeId: string, filters: CalendarFilters): Promise<CalendarResponse> {
    try {
      const { startDate, endDate, eventType, leaveType, status } = filters;

      // Get leave requests for the date range
      const leaveRequests = await this.getLeaveRequestsForCalendar(employeeId, {
        startDate: new Date(startDate),
        endDate: new Date(endDate),
        leaveType,
        status
      });

      // Convert leave requests to calendar events
      const events: CalendarEvent[] = leaveRequests.map(request => ({
        id: request.id,
        title: `${request.leaveType} - ${request.reason}`,
        type: 'leave' as const,
        startDate: new Date(request.startDate),
        endDate: new Date(request.endDate),
        allDay: true,
        leaveType: request.leaveType,
        status: request.status === 'escalated' ? 'pending' : request.status as 'pending' | 'approved' | 'rejected',
        color: this.getLeaveTypeColor(request.leaveType),
        description: request.reason,
        location: undefined
      }));

      // For now, we'll use empty holidays array since Holiday model doesn't exist
      const holidays: Holiday[] = [];
      const allEvents = events;

      // Filter by event type if specified
      const filteredEvents = eventType && eventType !== 'all' 
        ? allEvents.filter(event => event.type === eventType)
        : allEvents;

      // Get month statistics
      const monthStats = await this.getMonthStats(new Date(startDate), new Date(endDate));

      return {
        events: filteredEvents,
        holidays,
        filters,
        monthStats
      };
    } catch (error) {
      console.error('Error fetching calendar events:', error);
      throw new Error('Failed to fetch calendar events');
    }
  }

  /**
   * Get leave requests for calendar view
   */
  private static async getLeaveRequestsForCalendar(
    employeeId: string, 
    filters: {
      startDate: Date;
      endDate: Date;
      leaveType?: string;
      status?: string;
    }
  ) {
    const where: any = {
      userId: employeeId,
      OR: [
        // Leave request starts within the range
        {
          startDate: {
            gte: filters.startDate,
            lte: filters.endDate
          }
        },
        // Leave request ends within the range
        {
          endDate: {
            gte: filters.startDate,
            lte: filters.endDate
          }
        },
        // Leave request spans the entire range
        {
          AND: [
            { startDate: { lte: filters.startDate } },
            { endDate: { gte: filters.endDate } }
          ]
        }
      ]
    };

    if (filters.leaveType && filters.leaveType !== 'all') {
      where.leaveType = filters.leaveType;
    }

    if (filters.status && filters.status !== 'all') {
      where.status = filters.status;
    }

    return await prisma.leaveRequest.findMany({
      where,
      orderBy: { startDate: 'asc' }
    });
  }

  /**
   * Get holidays for calendar view
   * Note: Holiday model doesn't exist in current schema, returning empty array
   */
  private static async getHolidaysForCalendar(startDate: Date, endDate: Date): Promise<Holiday[]> {
    // TODO: Implement when Holiday model is added to schema
    return [];
  }

  /**
   * Get month statistics
   */
  private static async getMonthStats(startDate: Date, endDate: Date): Promise<MonthStats> {
    const totalDays = Math.ceil((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24)) + 1;
    
    // Calculate working days (excluding weekends)
    let workingDays = 0;
    for (let d = new Date(startDate); d <= endDate; d.setDate(d.getDate() + 1)) {
      const dayOfWeek = d.getDay();
      if (dayOfWeek !== 0 && dayOfWeek !== 6) { // Not Sunday (0) or Saturday (6)
        workingDays++;
      }
    }

    // TODO: Get holidays when Holiday model is added to schema
    const holidays = 0;

    return {
      totalDays,
      workingDays,
      leaveDays: 0, // This would be calculated from leave requests
      holidayDays: 0, // TODO: Calculate when Holiday model is added
      leaveUtilization: 0 // TODO: Calculate leave utilization percentage
    };
  }

  /**
   * Get color for leave type
   */
  private static getLeaveTypeColor(leaveType: string): string {
    switch (leaveType.toLowerCase()) {
      case 'annual':
      case 'annual leave':
        return '#3B82F6'; // Blue
      case 'sick':
      case 'sick leave':
        return '#EF4444'; // Red
      case 'casual':
      case 'casual leave':
        return '#8B5CF6'; // Purple
      case 'emergency':
      case 'emergency leave':
        return '#F59E0B'; // Orange
      case 'maternity':
      case 'maternity leave':
        return '#EC4899'; // Pink
      case 'paternity':
      case 'paternity leave':
        return '#06B6D4'; // Cyan
      default:
        return '#6B7280'; // Gray
    }
  }
}
