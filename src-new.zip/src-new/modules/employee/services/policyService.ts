import { PrismaClient } from '@prisma/client';
import { LeavePolicy } from '../../../types';

const prisma = new PrismaClient();

export interface PolicyFilters {
  status?: string;
  limit?: number;
}

export class PolicyService {
  /**
   * Get all policies with optional filtering
   */
  static async getPolicies(filters: PolicyFilters = {}): Promise<LeavePolicy[]> {
    try {
      const { status = 'active', limit = 50 } = filters;

      const where: any = {};
      
      // For now, we'll return all policies since the schema doesn't have an 'isActive' field
      // In a real implementation, you might want to add an 'isActive' field to the LeavePolicy model
      
      const policies = await prisma.leavePolicy.findMany({
        where,
        take: limit,
        orderBy: {
          createdAt: 'desc'
        }
      });

      // Transform the data to match the expected interface
      return policies.map(policy => ({
        id: policy.id,
        leave_type: policy.leaveType,
        total_days_per_year: policy.totalDaysPerYear,
        can_carry_forward: policy.canCarryForward,
        max_carry_forward_days: policy.maxCarryForwardDays || undefined,
        requires_approval: policy.requiresApproval,
        allow_half_day: policy.allowHalfDay,
        description: policy.description || ''
      }));
    } catch (error) {
      console.error('Error in PolicyService.getPolicies:', error);
      throw new Error('Failed to retrieve policies');
    }
  }

  /**
   * Get policy by ID
   */
  static async getPolicyById(id: string): Promise<LeavePolicy | null> {
    try {
      const policy = await prisma.leavePolicy.findUnique({
        where: { id }
      });

      if (!policy) {
        return null;
      }

      // Transform the data to match the expected interface
      return {
        id: policy.id,
        leave_type: policy.leaveType,
        total_days_per_year: policy.totalDaysPerYear,
        can_carry_forward: policy.canCarryForward,
        max_carry_forward_days: policy.maxCarryForwardDays || undefined,
        requires_approval: policy.requiresApproval,
        allow_half_day: policy.allowHalfDay,
        description: policy.description || ''
      };
    } catch (error) {
      console.error('Error in PolicyService.getPolicyById:', error);
      throw new Error('Failed to retrieve policy');
    }
  }
}
